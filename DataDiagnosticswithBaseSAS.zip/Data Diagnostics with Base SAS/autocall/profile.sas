﻿%macro profile(dsn);
%local MSGTYPE;
%let MsgType=NOTE;
%if %SUPERQ(dsn)= ? %then %do;
%Syntax:
   %put &MsgType- ;
   %put &MsgType: &SYSMACRONAME documentation:;
   %put &MsgType- ;
   %put &MsgType- Purpose: Create profile tables for a rent dataset.;
   %put &MsgType- ;
   %put &MsgType- Syntax: %nrstr(%%)&SYSMACRONAME(dsn);
   %put &MsgType- ;
   %put &MsgType- dsn: dataset name;
   %put &MsgType- ;
   %put &MsgType- Examples: ;
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(cleanme.va_rent);
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(cleanme.va_rent_demo);
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(cleanme.va_rent_practice);
   %put &MsgType- ;
   %put &MsgType- ;
   %return;
%end; 
%if %SUPERQ(dsn)= %then %do;
  	%let MsgType=ERROR;
   %put &MsgType- ;
  	%put &MsgType: (&sysmacroname) You must specify a dataset.;
   %put &MsgType- ;
	%goto Syntax;
%end;
/* Get some info to work with */
title "Profiling %superq(dsn) - %putn(%dsnattr(%superq(dsn),nlobs),comma12.) rows";
title2 "Number of distinct values by variable";
ods output NLevels=stats;
proc freq data=%superq(dsn) nlevels order=freq;
   tables _all_/noprint;
run;
ods output close;

/* Get a list of potential categorical and analysis variables */
title "Profiling %superq(dsn) - %putn(%dsnattr(%superq(dsn),nlobs),comma12.) rows";
proc FedSQL;
drop table profile force;
create table Profile as
select Column_Name as "Column"
     , Type_name as "DataType"
     , Case
         when NUM_PREC_RADIX>0 then 8 
           else Column_Size 
       end as "Size"
     , NNonMissLevels*1 as "UniqueValues"
     , Case 
         when NMissLevels>0 then 'Yes'
         else 'No'
       end as "MissingValues"
     , Case 
         when NMissLevels>1 then 'Yes'

         else 'No'
       end as "SpecialMissingValues"
   from dictionary.columns
   inner join
   work.stats
   on upcase(Column_name)=upcase(TableVar)
   where table_cat='CLEANME' and table_name='VA_RENT'
;
quit;

proc sql noprint;
select Column into :cat_cols separated by ' '
   from profile
   where DataType like '%CHAR%'
     and 1 < UniqueValues<=%dsnattr(%superq(dsn),nlobs)*.01
;
select Column into :num_cat_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and 1 < UniqueValues<=20
;
select Column into :analysis_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and UniqueValues > 20
;
quit;

%put NOTE: Possible categorical variables are:;
%put NOTE- &cat_cols &num_cat_cols;
%put NOTE-  ;
%put NOTE- Possible analysis variables are:;
%put NOTE- &analysis_cols ;

proc FedSQL;
title2 "Sample rows from %superq(dsn)";
	select * from %superq(dsn) limit 3;
title2 "%superq(dsn) column information";
	select * from Profile;
quit;

/* Profile the data */
title2 "%superq(dsn) potential categories";
proc freq data=%superq(dsn);
   tables &cat_cols &num_cat_cols/nocum nopercent;
run;
title;
%mend profile;
