﻿%macro rentPlot(type,dsn);
%local MSGTYPE;
%let MsgType=NOTE;
%if %SUPERQ(type)= ? %then %do;
%Syntax:
   %put &MsgType- ;
   %put &MsgType: &SYSMACRONAME documentation:;
   %put &MsgType- ;
   %put &MsgType- Purpose:*Data Diagnostics in Base SAS workshop*;
   %put &MsgType-          Create Rent and Bedroom plots for va_rent data;
   %put &MsgType- ;
   %put &MsgType- Syntax: %nrstr(%%)&SYSMACRONAME(Type,dsn);
   %put &MsgType- ;
   %put &MsgType- type: Value of the categorical variable Type.;
   %put &MsgType- dsn:  Name of data set to process.;
   %put &MsgType- ;
   %put &MsgType- Examples: ;
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(Apartment,cleanme.va_rents_demo);
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(Single-Family,cleanme.va_rents_practice);
   %put &MsgType- ;
   %put &MsgType- ;
   %return;
%end; 
%if %SUPERQ(type)= %then %do;
  	%let MsgType=ERROR;
   %put &MsgType- ;
  	%put &MsgType: (&sysmacroname) You must specify a unit type.;
   %put &MsgType- ;
	%goto Syntax;
%end;
%if %SUPERQ(dsn)= %then %do;
  	%let MsgType=ERROR;
   %put &MsgType- ;
  	%put &MsgType: (&sysmacroname) Dataset name required.;
   %put &MsgType- ;
   %put &MsgType- ;
	%let dsn=practice;
%end;

proc sql noprint;
select count(*) into :unitcount trimmed
	from &dsn
   where upcase(type)=upcase("%superq(type)");
quit;


title "There are &unitcount %superq(type) units";
%if %superq(type)= %then %do;
title "There are &unitcount units with missing Type";
%end;
ods layout gridded COLUMNS=2 COLUMN_GUTTER=.1in width=3in;

ods region;
title "Rent Histogram";
proc sgplot data=&dsn(keep=Type Rent) noautolegend;
  where upcase(type)=upcase("%superq(type)");
  histogram Rent;
  density Rent;
  keylegend / location=inside position=topright across=1 noborder;
run;
ods region;
title "Rent Box Plot";
proc sgplot data=&dsn(keep=Type Rent);
  hbox Rent;
  where upcase(type)=upcase("%superq(type)");
run;

ods region;
title "Bedrooms Histogram";
proc sgplot data=&dsn(keep=Type Bedrooms) noautolegend;
  where upcase(type)=upcase("%superq(type)");
  histogram Bedrooms;
  density Bedrooms;
  keylegend / location=inside position=topright across=1 noborder;
run;
ods region;
title "Bedrooms Box Plot";
proc sgplot data=&dsn(keep=Type Bedrooms);
  hbox Bedrooms;
  where upcase(type)=upcase("%superq(type)");
run;
ods layout end;
title;
%mend rentPlot;
