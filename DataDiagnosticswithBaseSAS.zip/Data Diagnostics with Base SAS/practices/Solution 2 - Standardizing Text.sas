﻿/****************************************************************************** 
 Solution to Practice 2 - Standardizing Text
 
 Standardize the text fields in cleanme.va_rent_practice and store the result
 as cleanme.va_rent_practice_std. You'll use this as input to subsequent steps.
******************************************************************************/

/****************************************************************************** 
 Step 1 -  Pre-standardization report 
 Run this code to reset the data and then review the report. 
******************************************************************************/
ods noproctitle;
title "Before Standardizing";
proc freq data=cleanme.va_rent_practice;
   tables StateName StateCode County_Name Type /nopercent nocum missing;
run;

/****************************************************************************** 
 Step 2 - Standardize the data
 This DATA step contains code that uses regular expressions to identify and fix 
 CountyName values. Add code to ensure all Type and StateName values are in 
 proper case, and StateCode values are in upper case, then run the DATA step.
******************************************************************************/
data cleanme.va_rent_practice_std;
   set cleanme.va_rent_practice;
   /* Add code to ensure all Type and StateName values are in proper case, 
      and StateCode values are in upper case. */
   Type=propcase(type);
   StateName=propcase(StateName);
   StateCode='VA';
   /* Adding the 'o' modifier to the regex ensures it compiles only once */
   if prxmatch('/((?:Ja)i?(?:mes)(:?\s+|\-)(?:C|S)ity Countr?y)/io',county_name)>0 then county_name='James City County';
   if prxmatch('/(wmbg|williamsburg)(\s+(C(i|oun)ty)?)*$/io',county_name)>0 then county_name='City of Williamsburg';
run;

/****************************************************************************** 
 Step 3 -  Post-standardization report 
 Run this code and review the report. Verify that standardization issues with 
 Type, StateName, StateCode, and CountyName have been resolved.
 Question: How many rows are missing the Type value?
 Answer: 1
******************************************************************************/
title "After Standardizing";
proc freq data=cleanme.va_rent_practice_std;
   tables StateName StateCode County_Name Type /nopercent nocum missing;
run;
title; footnote;

