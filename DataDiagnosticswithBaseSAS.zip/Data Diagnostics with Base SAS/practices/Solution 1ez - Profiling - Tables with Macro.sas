﻿/****************************************************************************** 
 Solution to Practice 1ez: Profiling - Tables with macro
 
 You will be working with the cleanme.va_rent_practice data set.
 The structure is identical to the data seen in the demos.
 If you have already modifed the data, use this to code restore it:
 %include "&path/data/reset.sas";

 Use the %profile macro to profile cleanme.va_rent_practices.  
 The macro is in your autocall path. You can submit %profile(?) to get some 
 syntax help in the log. 

 When execution finishes, answer these questions:
 a. Are any Bedroom values outside the rang of 0 to 6? 
	 Answer: Yes. One has a value of 0.999
 b. Does the number of unique ID values match the number of observations 
    in cleanme.va_rent_practice? 
	 Answer: Yes. There are no missing values, and all are unique. 
 c. Of the variables profiled, which ones probably need no further cleaning? 
    Answer: metro_name and fips_code    
******************************************************************************/ 
%profile(cleanme.va_rent_practice)
