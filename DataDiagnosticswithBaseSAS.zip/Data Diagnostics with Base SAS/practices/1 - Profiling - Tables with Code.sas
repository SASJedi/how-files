﻿/****************************************************************************** 
 Practice 1 - Profiling - Tables with Code

 You will be working with the cleanme.va_rent_practice data set.
 The structure is identical to the data seen in the demos.
******************************************************************************/

/****************************************************************************** 
 Step 1 - Find out how many unique values are in the data
 Add an ODS OUTPUT statement before the PROC FREQ to capture NLevels 
 in a data set named work.stats, then run all of the code in this section.
 Review the two reports and verify that work.stats contains the same 
 information as the PROC FREQ NLEVELS report.
******************************************************************************/
/*Ensure the data is in its starting state*/
%include "&path/data/reset.sas";

title "cleanme.va_rent_practices - %putn(%dsnattr(cleanme.va_rent_practice,nlobs),comma12.) rows";
ods output /* complete this statement */;
proc freq data=cleanme.va_rent_practice nlevels order=freq;
   tables _all_/noprint;
run;
ods output close;

title2 "work.stats data";
proc sql;
select * from work.stats;
quit;

/****************************************************************************** 
 Step 2 -  Get info about categorical and analysis variables 
 Execute this PROC FedSQL join of work.stats to dictionary.columns to obtain
 more information about the variables. No editing required.
******************************************************************************/
proc FedSQL;
drop table profile force;
create table Profile as
select Column_Name as "Column"
     , Type_name as "DataType"
     , Case
         when NUM_PREC_RADIX>0 then 8 
           else Column_Size 
       end as "Size"
     , NNonMissLevels*1 as "UniqueValues"
     , Case 
         when NMissLevels>0 then 'Yes'
         else 'No'
       end as "MissingValues"
     , Case 
         when NMissLevels>1 then 'Yes'

         else 'No'
       end as "SpecialMissingValues"
   from dictionary.columns
	inner join 
		  work.stats
	on upcase(COLUMN_NAME)=upcase(TableVar)
   where table_cat='CLEANME' and table_name='VA_RENT_PRACTICE'
;
quit;
/****************************************************************************** 
 Step 3 -  Get macro lists of potential categorical and analysis variables 
 Execute this series of PROC SQL queries to create macor variables:
    cat_cols - a space-delimited list of potential character categorical variables
    num_cat_cols - a space-delimited list of potential numeric categorical variables
    analysis_cols - a space-delimited list of potential numeric analysis variables
 Review the log to see the lists you created.
******************************************************************************/
proc sql noprint;
select Column into :cat_cols separated by ' '
   from profile
   where DataType like '%CHAR%'
		/*The %dsnattr macro call returns the number of observations 
	     in cleanme.va_rent_practice.*/
     and 1 < UniqueValues<=%dsnattr(cleanme.va_rent_practice,nlobs)*.01
;
select Column into :num_cat_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and 1 < UniqueValues<=20
;
select Column into :analysis_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and UniqueValues > 20
;
quit;

%put NOTE: Possible categorical variables are:;
%put NOTE- &cat_cols &num_cat_cols;
%put NOTE-  ;
%put NOTE- Possible analysis variables are:;
%put NOTE- &analysis_cols ;

/****************************************************************************** 
 Step 4 -  Take a peek at some sample data and the profile data 
 Execute this series of PROC FedSQL queries and review the output. 
 Answer these questions:
 Question 1: Are any Bedroom values outside the rang of 0 to 6? 
   Answer 1:  
 Question 2: Does the number of unique ID values match the number of observations 
    in cleanme.va_rent_practice? 
   Answer 2:  
******************************************************************************/
/*%dsnattr returns the number of observations in cleanme.va_rent_practice.*/
title "cleanme.va_rent_practices has %dsnattr(cleanme.va_rent_practice,nlobs) rows";
title2 "cleanme.va_rent_practices profile tables";
proc FedSQL;
	title2 "Sample rows from cleanme.va_rent_practice";
	select * from cleanme.va_rent_practice limit 10;
	title2 "cleanme.va_rent_practice column information";
	select * from Profile;
quit;

/****************************************************************************** 
 Step 5 -  Finish profiling the data 
 Complete the PROC FREQ TABLES statement so that a table is generated for each
 categorical variable. The variable lists are stored in the two macro 
 variables created in Step 2.b above:
  1: cat_cols - list of character categorical variables
  2: num_cat_cols - list of numeric categorical variables

 Answer these questions:
 Question 1: Of the variables profiled, which ones probably need no further cleaning? 
   Answer 1: 
******************************************************************************/ 
title2 "cleanme.va_rent_practice potential categories";
proc freq data=cleanme.va_rent_practice;
   tables  /* add macro variable references here*/ 
        /nocum nopercent;
run;
title;
