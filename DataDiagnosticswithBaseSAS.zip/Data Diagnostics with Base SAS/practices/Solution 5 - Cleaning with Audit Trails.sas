﻿/******************************************************************************
 Solution for Practice 5 - Cleaning with Audit Trails:
 Use business rules for the data and integrity constraints to separate the 
 good and suspect records.

 Here are the business rules:
 1. Record ID is required and must be unique
 2. The only valid value for State Code is "VA"
 3. Valid unit Type values are "Apartment","Efficiency","Multi-Family"
    ,"Single-Family","Townhouse".
 4. Bedroom count must be in the range 0 to 6.
 5. Rents must be in the range $500 to $5,500 per month.

 This step uses the cleanme.va_rent_practice_std dataset produced in Step 2.
 If you didn't complete step 2, run this code to produce the data set:
 %include "&path/practices/Solution 2 - Standardizing Text.sas";
******************************************************************************/

/******************************************************************************
 Prelimniary: 
 To clean up the WORK library, submit all code in this section without modification.
******************************************************************************/
proc datasets library=work kill nolist nodetails; run; quit;

/******************************************************************************
 Step 1: 
 Use PROC SQL and a CREATE TABLE - LIKE statement to create an empty table 
 named work.va_rent_practice structured like cleanme.va_rent_practice_std.
******************************************************************************/
proc sql;
create table work.va_rent_practice 
	like cleanme.va_rent_practice_std
;
quit;

/******************************************************************************
 Step 2:
   Use PROC DATASETS to modify the va_rent_practice table in the WORK library:
	- add constraints for StateCode and Rent
	- initiate auditing of va_rent_practice
   Add the requisite code to the PROC DATASETS step below as indicated in the
   comments to validate StateCode and Rent.   
******************************************************************************/
proc datasets library=work nolist nodetails;
	modify va_rent_practice;
	/* Record ID is required and must be unique
	   Primary Key enforces both UNIQUE and NOT NULL */
	ic create ID_pk = primary key (ID) 
		message="Bad ID - missing or not unique" msgtype=user;
	/* Valid unit Type values are 'Efficiency','Single Family'
		,'Town House','Multi-Family', and 'Apartment' */
	ic create Type_ck = check 
   	(where=(Type in("Apartment","Efficiency","Multi-Family","Single-Family","Townhouse"))) 
	    message="Bad Type" msgtype=user;
	/* Bedroom count must be between 0 and 6, inclusive */
	ic create BR_Count_ck = check 
   	(where=(Bedrooms between 0 and 6)) 
	    message="Bedroom count not between 0 and 6" msgtype=user;
	/*****************************************************
	 The only valid value for StateCode is "VA". Use an 
    IC CREATE statement to add a constraing named 
    StateCode_ck to enforce the restriction:
       where=(StateCode='VA')
    If violated, generate a user error message saying:
       "Bad State - not VA"
   *****************************************************/
	ic create StateCode_ck = check 
		(where=(StateCode='VA')) 
		message="Bad State - not VA" msgtype=user;
	/*****************************************************
    Rents must be between 500 and 5500, inclusive. Use an 
    IC CREATE statement to add a constraing named Rent_ck
    to enforce the restriction:
       where=(Rent between 500 and 5500)
    If violated, generate a user error message saying:
       "Rent not between 500 and 5500"
   *****************************************************/
	ic create Rent_ck = check 
   	(where=( Rent between 500 and 5500)) 
	    message="Rent not between 500 and 5500" msgtype=user;
	/*****************************************************
	 Initiate the audit trail on va_rent_practice.
   *****************************************************/
	audit va_rent_practice;
   initiate;
run;
quit;

/******************************************************************************
 Step 3:
 Use PROC APPEND to append the original data (cleanme.va_rent_practice_std)
 to the empty base table (work.va_rent_practice). Rows that don't meet the 
 contraint criteria are rejected, and the audit trail records details of the 
 rejected tansactions.
******************************************************************************/
proc append base=work.va_rent_practice 
				data=cleanme.va_rent_practice_std;
run;

/******************************************************************************
 Step 4:
 Extract and review the audit trail information for the rejected rows.
 Submit the code in this section without modification. Review the "Record of 
 rejected records" report, then answer these questions:
 Question 1: How many records were rejected?
   Answer 1: 7
 Question 2: How many records were rejected because of a bad type value?
   Answer 2: 1
******************************************************************************/
title "Sample of work.va_rent_practice audit trail data";
proc print data=work.va_rent_practice(type=audit obs=10) noobs;
run;

/* _ATMESSAGE_ values for errors start with an 'ERROR:' */
proc append base=work.audit_data 
            data=work.va_rent_practice(type=audit keep=ID _ATMESSAGE_
				                           rename=(_ATMESSAGE_=Reason) 
                                       where=(Reason like 'ERROR:%'));
run;

title "Record of rejected records";
proc print data=work.audit_data ;
run;

/******************************************************************************
 Step 5: 
 Join cleanme.va_rent_practice_std to work.work.audit_data to create a table 
 named cleanme.va_rent_practice_audit_sus containing suspicious records.
 Include all columns from cleanme.va_rent_practice_std and the Reason column
 from the audit data to help identify the problem. Review the report titled
 "Suspicious records - cleanme.va_rent_practice_audit_sus", then answer 
 these questions:
 Question 1: How many Townhouse records were rejected?
   Answer 1: None
 Question 2: How many bedrooms are in the rejected Apartment record?
   Answer 2: 999
******************************************************************************/
proc sql;
create table cleanme.va_rent_practice_audit_sus as
select distinct orig.*
		,Reason
	from cleanme.va_rent_practice_std as orig
	   inner join
		  work.audit_data as bad
	on bad.id=orig.id
	order by ID
;
quit;
title "Suspicious records - cleanme.va_rent_practice_audit_sus";
proc sql number;
select * 
	from cleanme.va_rent_practice_audit_sus
;
quit;

/******************************************************************************
 Step 6: 
 Select all records from cleanme.va_rent_practice_std that do not have a 
 corresponding error in the work.va_rent_practice audit data and create
 a table named clean.va_rent_practice_audit containing only the clean records.
 Include only columns from cleanme.va_rent_practice_std in the output.
******************************************************************************/
proc sql;
create table clean.va_rent_practice_audit as
select distinct orig.*
	from cleanme.va_rent_practice_std as orig
	where id not in 
		(/* write a query here that extracts unique IDs 
		    from cleanme.va_rent_practice_audit_sus */
       select distinct id 
          from cleanme.va_rent_practice_audit_sus)
	order by ID
;
quit;

/******************************************************************************
 Step 7: 
 Submit the code in this section without modification. Review the resulting 
 report and answer the following question:
 Question: Considering the values of Bedroom visible in the report, will further 
           cleaning be required? 
 Answer: Yes. Record JCC0005 shows a fractional Bedroom.
******************************************************************************/
title "Sample clean records - clean.va_rent_practice_audit";
proc sql;
select * 
	from clean.va_rent_practice_audit(obs=10)
;
quit;
