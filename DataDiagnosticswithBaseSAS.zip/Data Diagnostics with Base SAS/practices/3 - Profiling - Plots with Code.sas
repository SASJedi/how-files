﻿/****************************************************************************** 
 Practice 3 - Profiling - Plots with Code
 Plot values of Rent and Bedrooms by Type 

 This step uses the cleanme.va_rent_practice_std dataset produced in Step 2.
 If you didn't complete step 2, run this code to produce the data set:
 %include "&path/practices/Solution 2 - Standardizing Text.sas";
******************************************************************************/
/****************************************************************************** 
 Create plots for Type='Single-Family' 

 Step 1:
 Count the Single-Family units in the data using an SQL query
******************************************************************************/






	
/****************************************************************************** 
 Step 2:
 In the title, replace XXXX with the result of the SQL query above, then run
 all of the code in this step. Answer the following question:
 Question 1: What is the maximum number of bedrooms for Single-Family units? 
   Answer 1: 
******************************************************************************/
title "There are XXXX Single-Family units";
ods layout gridded COLUMNS=2 COLUMN_GUTTER=.1in width=3in;

ods region;
title "Rent Histogram";
proc sgplot data=cleanme.va_rent_practice_std(keep=Type Rent) noautolegend;
  where upcase(type)=upcase("Single-Family");
  histogram Rent;
  density Rent;
  keylegend / location=inside position=topright across=1 noborder;
run;

ods region;
title "Rent Boxplot";
proc sgplot data=cleanme.va_rent_practice_std(keep=Type Rent);
  hbox Rent;
  where upcase(type)=upcase("Single-Family");
run;

ods region;
title "Bedrooms Histogram";
proc sgplot data=cleanme.va_rent_practice_std(keep=Type Bedrooms) noautolegend;
  where upcase(type)=upcase("Single-Family");
  histogram Bedrooms;
  density Bedrooms;
  keylegend / location=inside position=topright across=1 noborder;
run;

ods region;
title "Bedrooms Boxplot";
proc sgplot data=cleanme.va_rent_practice_std(keep=Type Bedrooms);
  hbox Bedrooms;
  where upcase(type)=upcase("Single-Family");
run;
ods layout end;
title;

/****************************************************************************** 
 Step 3:
 Determine the distinct values for TYPE. Answer the following questions:
 Question 1: Does Type have any missing values? 
   Answer 1: 
 Question 2: How many non-missing values are there for Type? 
   Answer 2: 
******************************************************************************/












/****************************************************************************** 
 Step 4:
 Create a set of plots for each non-missing value of Type. You could copy and
 paste the code above 4 more times, changing the value for type, but that 
 would take a long time. Instead, use the %rentplot macro to generate a plot
 set for Type values of Apartment, Efficiency, Multi-Family, and Townhouse.
 Run the code in this section and answer the following question:
 Question 1: Do any Efficiency units have more than 0 bedrooms?
   Answer 1: No.
 Question 2: What problems can you see with the Apartment bedroom data?
   Answer 2: There is at least one enormously high outlier value.
******************************************************************************/
/* Run this to get syntax help in the log */
%rentplot(?)

/* Write a macro call for each value of Type */




