﻿/****************************************************************************** 
 Solution for Practice 3ez - Profiling - Plots with Macro
 Plot values of Rent and Bedrooms by Type 

 This step re-creates the cleanme.va_rent_practice_std dataset produced in 
 Step 2, then uses it for processing.
******************************************************************************/

/****************************************************************************** 
 Step 1:
 Create a set of plots for each value of Type using the %rentplots macro.
 Run all of the code in this section, then answer the following questions:
 Question 1: How many Single-Family units are there? 
   Answer 1: 1377
 Question 2: What is the maximum number of bedrooms for Single-Family units? 
   Answer 2: 6
 Question 3: Do any Efficiency units have more than 0 bedrooms?
   Answer 3: No.
 Question 4: What problems can you see with the Apartment bedroom data?
   Answer 4: There is at least one enormously high outlier value.
******************************************************************************/
/*Ensures the input data is standardized*/
%include "&path/practices/Solution 2 - Standardizing Text.sas";

/* Run this to get syntax help in the log */
%rentplots(?)

/* Write the macro call to produce the plots for cleanme.va_rent_practice_std*/
%rentplots(cleanme.va_rent_practice_std)
