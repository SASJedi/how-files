%let path=~/my_shared_file_links/u44953736/Data Diagnostics with Base SAS;
libname cleanme "&path/data";
libname backup  "&path/data/backup";
libname clean  "&path/data/clean";
options mrecall mautolocdisplay sasautos=("&path/autocall",SASAUTOS);

title "Tables Used in This Course ";
proc sql number;
select libname 'Library'
      ,memname 'Table'
      ,nlobs format=comma8. 'Obs Count'
      ,round(filesize/1000000,.1) 'File Size (MB)'
   from dictionary.tables
   where libname ='CLEANME'
   order by 1,2
   ;
quit;

title;footnote;

