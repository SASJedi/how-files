proc datasets library=clean kill nolist nodetails;
run;quit;
proc datasets library=cleanme nolist nodetails;
run;quit;

proc copy in=backup out=cleanme;
run;
