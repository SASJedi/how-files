﻿/****************************************************************************** 
 Demo 3 - Profiling - Plots
 Plot values of Rent and Bedrooms by Type 
 Uses data produced in Step 2 with standardized text fields as input
 %include "&path/demos/2 - Standardizing Text.sas";
******************************************************************************/
/****************************************************************************** 
 Step 1: Count the Single-Family units in the data using an SQL query
******************************************************************************/
proc sql;
select count(*) 
	from cleanme.va_rent_demo_std
	where Type='Single-Family'
;
quit;
	
/****************************************************************************** 
 Step 2: Create plots for Type='Single-Family' 
 In the title, replace XXXX with 3330, the result of the SQL query above. 
 Run all of the code in this step. 
******************************************************************************/
title "There are XXXX Single-Family units";
ods layout gridded COLUMNS=2 COLUMN_GUTTER=.1in width=3in;

ods region;
title "Rent Histogram";
proc sgplot data=cleanme.va_rent_demo_std(keep=Type Rent) noautolegend;
  where upcase(type)=upcase("Single-Family");
  histogram Rent;
  density Rent;
  keylegend / location=inside position=topright across=1 noborder;
run;

ods region;
title "Rent Boxplot";
proc sgplot data=cleanme.va_rent_demo_std(keep=Type Rent);
  hbox Rent;
  where upcase(type)=upcase("Single-Family");
run;

ods region;
title "Bedrooms Histogram";
proc sgplot data=cleanme.va_rent_demo_std(keep=Type Bedrooms) noautolegend;
  where upcase(type)=upcase("Single-Family");
  histogram Bedrooms;
  density Bedrooms;
  keylegend / location=inside position=topright across=1 noborder;
run;

ods region;
title "Bedrooms Boxplot";
proc sgplot data=cleanme.va_rent_demo_std(keep=Type Bedrooms);
  hbox Bedrooms;
  where upcase(type)=upcase("Single-Family");
run;
ods layout end;
title;
/****************************************************************************** 
 Step 3:
 Determine the distinct values for TYPE. Answer the following questions:
******************************************************************************/
proc sql number;
select type, count(*) as Count
   from cleanme.va_rent_demo_std
	group by type
;
quit;

/****************************************************************************** 
 Step 4:
 Create a set of plots for each non-missing value of Type. 
 You could copy and paste the code above 4 more times, changing the value for 
 type, but that would take a lot of typing. 
 Instead, you could use the %rentplot macro to generate the plots.
******************************************************************************/
/* Run this to get syntax help in the log */
%rentplot(?)

%rentplot(Apartment,cleanme.va_rent_demo_std)
%rentplot(Efficiency,cleanme.va_rent_demo_std)
%rentplot(Multi-Family,cleanme.va_rent_demo_std)
%rentplot(Single-Family,cleanme.va_rent_demo_std)
%rentplot(Townhouse,cleanme.va_rent_demo_std)

/* Even better, use the rentPlots macro to get them all at once */
%rentplots(cleanme.va_rent_demo_std)
