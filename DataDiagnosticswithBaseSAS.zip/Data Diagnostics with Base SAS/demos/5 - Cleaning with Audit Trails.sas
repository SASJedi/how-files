﻿/******************************************************************************
 Demo 5 - Cleaning with Audit Trails
 If you know the business rules to which you want your data to conform, you 
 can separate the good from the suspect using integrity constraints and 
 audit trails.

 Our rules are these:
 1. Record ID is required and must be unique
 2. The only valid value for State Code is "VA"
 3. Valid unit Type values are "Apartment","Efficiency","Multi-Family"
    ,"Single-Family","Townhouse"
 4. Bedroom count must be between 0 and 6 
 5. Rents must be between $500 and $5,500 per month
******************************************************************************/

/******************************************************************************
 Prelimniaries: Clean up the WORK library.
******************************************************************************/
proc datasets library=work kill nolist nodetails; run; quit;

/******************************************************************************
 Step 1: Create an empty table with the same structure as the original
******************************************************************************/
proc sql;
create table work.va_rent_demo 
	like cleanme.va_rent_demo_std
;
quit;

/******************************************************************************
 Step 2: Use PROC DATASETS to add constraints with custom messages and initiate 
         auditing on the empty work.va_rent_demo table to
******************************************************************************/
proc datasets library=work nolist nodetails;
	modify va_rent_demo;
	/* Record ID is required and must be unique
	   Primary Key enforces both UNIQUE and NOT NULL */
	ic create ID_pk = primary key (ID) 
		message="Bad ID - missing or not unique" msgtype=user;
	/* The only valid value for State Code is "VA"*/
	ic create StateCode_ck = check 
		(where=(StateCode='VA')) 
		message="Bad State - not VA" msgtype=user;
	/* Valid unit Type values are 'Efficiency','Single Family'
		,'Town House','Multi-Family', and 'Apartment' */
	ic create Type_ck = check 
   	(where=(Type in("Apartment","Efficiency","Multi-Family","Single-Family","Townhouse"))) 
	    message="Bad Type" msgtype=user;
	/* Bedroom count must be an integer */
	ic create BR_Integer_ck = check 
   	(where=(Bedrooms=int(Bedrooms))) 
	    message="Bedroom count contains a fraction" msgtype=user;
	/* Bedroom count must be between 0 and 6*/
	ic create BR_Count_ck = check 
   	(where=(Bedrooms between 0 and 6)) 
	    message="Bedroom count not between 0 and 6" msgtype=user;
	ic create Rent_ck = check 
   	(where=(Rent between 500 and 5500)) 
	    message="Rent not between 500 and 5500" msgtype=user;
	/* Initiate the audit trail */
	audit va_rent_demo;
   initiate;
run;
quit;

/******************************************************************************
 Step 3: Append the existing data to the new table. Rows that don't meet the 
 criteria are rejected, and the audit trail shows the details of the transaction.
******************************************************************************/
proc append base=work.va_rent_demo 
				data=cleanme.va_rent_demo_std;
run;

/******************************************************************************
 Step 4: Review the audit trail to gather information about the rejected rows.
******************************************************************************/
title "work.va_rent_demo audit trail data";
proc print data=work.va_rent_demo(type=audit obs=10) noobs;
run;

/******************************************************************************
 Step 5: Extract rejected row data to use as a format for lookups.
******************************************************************************/
/* _ATMESSAGE_ values for errors start with an 'ERROR:' */
data work.bad_id_format;
   retain fmtname '$badID';
   set work.va_rent_demo(type=audit keep=ID _ATMESSAGE_
		                   rename=(_ATMESSAGE_=Label ID=Start) 
                         where=(Label like 'ERROR:%'));
run;
proc format cntlin=work.bad_id_format fmtlib;
run;

/******************************************************************************
 Step 5 -
 Separate the clean from the sus.
******************************************************************************/
/* The bad and the ugly */
proc sql;
create table cleanme.va_rent_demo_audit_sus as
select *, put (ID,$badID.) as Problem
	from cleanme.va_rent_demo_std 
	where put (ID,$badID.) like 'ERROR%'
	order by ID
;
quit;

title "Suspicious records - cleanme.va_rent_demo_audit_sus";
proc sql;
select * 
	from cleanme.va_rent_demo_audit_sus
;
quit;

/* The good */
proc sql;
create table clean.va_rent_demo_audit as
select *
	from cleanme.va_rent_demo_std 
	where put (ID,$badID.) not like 'ERROR%'
	order by ID
;
quit;

title "Sample clean records - clean.va_rent_demo_audit";
proc sql;
select * 
	from clean.va_rent_demo_audit(obs=10)
;
quit;

/******************************************************************************
 Step 6 - Profile the cleaned data
******************************************************************************/
%profile(clean.va_rent_demo_audit)
%rentplots(clean.va_rent_demo_audit)

