﻿/****************************************************************************** 
 Practice 2 - Standardizing Text
******************************************************************************/
/****************************************************************************** 
 Step 1 -  Pre-standardization report 
 Run this code to reset the data and then review the report. 
******************************************************************************/
/* Ensure data is starting from a level playing field */
%include "&path/data/reset.sas";

ods noproctitle;
title "Before Standardizing";
proc freq data=cleanme.va_rent_demo;
   tables StateName StateCode County_Name Type /nopercent nocum missing;
run;


/****************************************************************************** 
 Step 1 -  Pre-standardization report 
******************************************************************************/
%include "&path/data/reset.sas";
ods noproctitle;
title "Before Standardizing";
proc freq data=cleanme.va_rent_practice;
   tables StateName StateCode County_Name Type /nopercent nocum missing;
run;

/****************************************************************************** 
 Step 2 - Standardize the data
******************************************************************************/
data cleanme.va_rent_demo_std;
   set cleanme.va_rent_demo;
   Type=propcase(type);
   StateName=propcase(StateName);
   StateCode='VA';
   /* Adding the 'o' modifier to the regex ensures it compiles only once */
   if prxmatch('/((?:Ja)i?(?:mes)(:?\s+|\-)(?:C|S)ity Countr?y)/io',county_name)>0 then county_name='James City County';
   if prxmatch('/(wmbg|williamsburg)(\s+(C(i|oun)ty)?)*$/io',county_name)>0 then county_name='City of Williamsburg';
run;

/****************************************************************************** 
 Step 3 -  Post-standardization report 
******************************************************************************/
title "After Standardizing";
proc freq data=cleanme.va_rent_demo_std;
   tables StateName StateCode County_Name Type /nopercent nocum missing;
run;

