﻿/****************************************************************************** 
 Demo 1 - Profiling - Tables with Code

 You will be working with the cleanme.va_rent_practice data set.
 The structure is identical to the data seen in the demos.
******************************************************************************/

/****************************************************************************** 
 Step 1 - Find out how many unique values are in the data
******************************************************************************/
title "cleanme.va_rent_demos - %putn(%dsnattr(cleanme.va_rent_demo,nlobs),comma12.) rows";
ods output NLevels=stats;
proc freq data=cleanme.va_rent_demo nlevels order=freq;
   tables _all_/noprint;
run;
ods output close;

/****************************************************************************** 
 Step 2 -  Get info about categorical and analysis variables 
******************************************************************************/
title "cleanme.va_rent_demo - %putn(%dsnattr(cleanme.va_rent_demo,nlobs),comma12.) rows";
proc FedSQL;
drop table profile force;
create table Profile as
select Column_Name as "Column"
     , Type_name as "DataType"
     , Case
         when NUM_PREC_RADIX>0 then 8 
           else Column_Size 
       end as "Size"
     , NNonMissLevels*1 as "UniqueValues"
     , Case 
         when NMissLevels>0 then 'Yes'
         else 'No'
       end as "MissingValues"
     , Case 
         when NMissLevels>1 then 'Yes'

         else 'No'
       end as "SpecialMissingValues"
   from dictionary.columns
   inner join
   work.stats
   on upcase(Column_name)=upcase(TableVar)
   where table_cat='CLEANME' and table_name='VA_RENT_DEMO'
;
quit;
/****************************************************************************** 
 Step 3 -  Get macro lists of potential categorical and analysis variables 
******************************************************************************/
proc sql noprint;
select Column into :cat_cols separated by ' '
   from profile
   where DataType like '%CHAR%'
		/*The %dsnattr macro call returns the number of observations 
	     in cleanme.va_rent_demo*/
     and 1 < UniqueValues<=%dsnattr(cleanme.va_rent_demo,nlobs)*.01
;
select Column into :num_cat_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and 1 < UniqueValues<=20
;
select Column into :analysis_cols separated by ' '
   from profile
   where DataType not like '%CHAR%'
     and UniqueValues > 20
;
quit;

%put NOTE: Possible categorical variables are:;
%put NOTE- &cat_cols &num_cat_cols;
%put NOTE-  ;
%put NOTE- Possible analysis variables are:;
%put NOTE- &analysis_cols ;

/****************************************************************************** 
 Step 4 -  Take a peek at some sample data and the profile data 
******************************************************************************/
title "cleanme.va_rent_demos profile tables";
proc FedSQL;
	title2 "Sample rows from cleanme.va_rent_demo";
	select * from cleanme.va_rent_demo limit 3;
	title2 "cleanme.va_rent_demo column information";
	select * from Profile;
quit;

/****************************************************************************** 
 Step 5 -  Finish profiling the data 
******************************************************************************/
title2 "cleanme.va_rent_demo potential categories";
proc freq data=cleanme.va_rent_demo;
   tables &cat_cols &num_cat_cols/nocum nopercent;
run;
title;

/* Or, use the profile macro to do the whole job */
%profile(cleanme.va_rent_demo)
