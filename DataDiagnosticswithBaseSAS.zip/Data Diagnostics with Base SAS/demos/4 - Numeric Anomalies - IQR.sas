﻿/****************************************************************************** 
 Demo 4 - Numeric Anomalies - IQR
 Uses the cleanme.va_rent_practice_std dataset produced in Step 2.
 %include "&path/practices/Solution 2 - Standardizing Text.sas";
******************************************************************************/
/****************************************************************************** 
 Step 1:
 Use PROC SUMMARY to analyze cleanme.va_rent_practice_std records where 
 Type='Apartment' and creates work.va_rent_practice_stats.
******************************************************************************/
/* Get info in a dataset using proc summary */
proc summary data=cleanme.va_rent_demo ;
   var rent bedrooms;
   class type;
   output out=work.va_rent_demo_stats(drop=_:)
   Min= Q1= Median= QRange= Q3= Max=/ autoname;
run;

/****************************************************************************** 
 Step 2: Review the data
******************************************************************************/
title "Virginia Rent - Statistics";
proc sql;
select Type
      ,Rent_Min  'Rent Minimum'
      ,Rent_Q1-(1.5*Rent_Qrange) 'Rent Lower Hinge'
		,Rent_Median  'Rent Median'
		,Rent_Q3+(1.5*Rent_Qrange) 'Rent Upper Hinge'
      ,Rent_Max  'Rent Maximum'
		,Bedrooms_Min  'Bedrooms Minimum'
		,Bedrooms_Q1-(1.5*Bedrooms_Qrange) 'Bedrooms Lower Hinge'
		,Bedrooms_Median  'Bedrooms Median'
		,Bedrooms_Q3+(1.5*Bedrooms_Qrange) 'Bedrooms Upper Hinge'
		,Bedrooms_Max  'Bedrooms Maximum'
	from work.va_rent_demo_stats
;
quit;

/****************************************************************************** 
 Step 3: 
 Use work.va_rent_demo_stats in a hash object for lookups to determine which 
 records are clean and which require review.
******************************************************************************/
data clean.va_rent_demo_iqr (Drop=Reason -- Bedrooms_Max)
     cleanme.va_rent_demo_review;
   set cleanme.va_rent_demo;
   /* Instantiate hash object to look up rent high/low cutoffs */
   length Reason $45;
   if _N_ = 1 then do;
		/* Just to get the variables in the PDV */
      if 0 then set va_rent_demo_stats;
		/* Initialize the hash */
      declare hash iqr(dataset:'va_rent_demo_stats');
      iqr.defineKey('Type');
      iqr.defineData('Rent_Q1','Bedrooms_Q1','Rent_Q3','Bedrooms_Q3','Rent_QRange','Bedrooms_QRange');
      iqr.defineDone();
   end;
   /* Compare actuals to high/low cutoffs */
   if iqr.find()=0 then do;
		/* Rent less than lower hinge-1.5*IQR */
      if Rent < Rent_Q1-(1.5*Rent_QRange) then do;
         Reason = CATX(', ',Reason,'Low Rent');
		end;
		/* Rent exceeds upper hinge+1.5*IQR */
      else if Rent > Rent_Q3+(1.5*Rent_QRange) then do;
         Reason = CATX(', ',Reason,'High Rent');
		end;
		/* Too few bedrooms for Type */
      if not (Type='Efficiency' and Bedrooms = 0) 
         and (Bedrooms < Bedrooms_Q1-(1.5*Bedrooms_QRange)) then do;
         Reason = CATX(', ',Reason,'Not enough bedrooms');
      end;
		/* Too many bedrooms for Type */
      if Type='Efficiency' and Bedrooms > 0 then do;
         Reason = CATX(', ',Reason,'Efficiencies don''t have bedrooms');
      end;
      else if Bedrooms > Bedrooms_Q3+(1.5*Bedrooms_QRange)
         then do;
         Reason = CATX(', ',Reason,'Too many bedrooms');
      end;
   end;
	/* If nothing was noted, write to clean */
   if missing (Reason) then output clean.va_rent_demo_iqr;
	else output cleanme.va_rent_demo_review;
run;

proc FedSQL number;
title "Reasons items require review";
select Reason, Count(*) as Frequency
   from cleanme.va_rent_demo_review
   group by Reason
   order by 2 desc 
;
title "Sample of items for review";
select ID, Type, Bedrooms, Rent, Reason
   from cleanme.va_rent_demo_review limit 10
;
title "Sample of cleaned data";
select * 
	from clean.va_rent_demo_iqr limit 10
;
quit;

/* Clean up the WORK library */
proc datasets library=work kill nolist nodetails;
run;
