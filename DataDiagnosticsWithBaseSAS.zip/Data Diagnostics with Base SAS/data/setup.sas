﻿options dlcreatedir;
libname path "&path";
libname path "&path/autocall";
libname cleanme "&path/data";
libname backup  "&path/data/backup";
libname clean   "&path/data/clean";
libname path "&path/demos";
libname path "&path/practices";
libname path clear;
options nodlcreatedir;

proc datasets library=cleanme kill nolist;  run; quit;

proc format cntlout=cleanme.formats;
   value type (default=15)
              0='Efficiency'
              1='Single-family'
              2='Townhouse'
              3='Multi-family'
              4='Apartment'
   ;
run;

filename json "&path/data/HUDStateRentData.json";
libname json json;
data backup.va_rent
	  backup.va_rent_demo
	  backup.va_rent_practice
	;
   if _n_=1 then call streaminit(12345);
   LENGTH ID $ 10;
   set json.data_counties (drop=ordinal: town_name small:);
   where county_name in ('James City County','New Kent County','York County','Williamsburg city');
   array fmr[0:6] Efficiency One_Bedroom Two_Bedroom Three_bedroom Four_Bedroom Five_Bedroom Six_Bedroom;
   drop Efficiency One_Bedroom Two_Bedroom Three_bedroom Four_Bedroom Five_Bedroom Six_Bedroom 
        _: FMR_Percentile;
   retain Five_Bedroom 2500 Six_Bedroom 3000;
   fmr[5]=round(fmr[4]*4.5/4,10);

   if char(county_name,1)='J' then do;
       _stop=7200;
       _prefix='JCC';
       _multiplier=.85;
   end;
   else if char(county_name,1)='N' then do;
      _stop=6500;
       _prefix='NKC';
       _multiplier=.95;
   end;
   else if char(county_name,1)='Y' then do;
      _stop=7500;
       _prefix='YKC';
       _multiplier=.75;
   end;
   else do;
      _stop=2100;
       _prefix='WBG';
       _multiplier=1.005;
   end;

   do _i=1 to _stop;
      id=cats(_prefix,put(_i,z4.));
      _Type=RAND('INTEGER',0,4);
      if _Type in (1,2) then Bedrooms=abs(ceil(RAND('NORMAL',3,1)));
      else if _Type in (3,4) then Bedrooms=abs(ceil(RAND('NORMAL',2,1)));
      else Bedrooms=0;
      if Bedrooms >6 then Bedrooms=6;
      Type=put(_type,type15.);
      if _type ne 0 and Bedrooms=0 then Bedrooms=2;
      Rent=round(FLOOR(RAND('NORMAL',fmr[bedrooms],fmr[bedrooms]/100))*_multiplier,100);
      if rand('UNIFORM') < 0.001 then do;
         _a=rand('INTEGER',1,4);
         if _a=1 then Rent=Rent*2; 
         else if _a=2 then Rent=Rent*.2;
         else if _a=3 then Type=lowcase(Type); 
         else Type="";
      end;
      if ID in ('JCC0001','YKC0001','WMB0001','NKC0001') then rent=999999;
      else if ID in ('JCC0002','YKC0002','WMB0002','NKC0002') then rent=.999999;
      else if ID in ('JCC0003','YKC0003','WMB0003','NKC0003') then rent=.;
      else if ID in ('JCC0004','YKC0004','WMB0004','NKC0004') then Bedrooms=999;
      else if ID in ('JCC0005','YKC0005','WMB0005','NKC0005') then Bedrooms=.999;
      else if ID in ('JCC0006','YKC0006','WMB0006','NKC0006') then StateName=lowcase(StateName);
      else if ID in ('JCC0007','YKC0007','WMB0007','NKC0007') then StateCode='WV';
      else if ID in ('JCC0008','YKC0008','WMB0008','NKC0008') then StateCode='';
      else if ID in ('JCC0009') then County_Name='Jaimes City County';
      else if ID in ('JCC0010') then County_Name='James City Country';
      else if ID in ('JCC0011') then County_Name='James-City County';
      else if ID in ('WBG0009') then County_Name='Williamsburg County';
      else if ID in ('WBG0010') then County_Name='Wmbg city';
      else if ID in ('WBG0011') then County_Name='City of Williamsburg';
      else if ID =('JCC0032') then Bedrooms=0;
      if ID =('JCC0012') then ID='JCC0011';
      if ID =('WBG0100') then ID='WBG0099';
      if ID =('NKC0100') then ID='';
	   output backup.va_rent;
      if rand('INTEGER',1,10) < 4 then do;
			output backup.va_rent_practice;
		end;
      else do;
			output backup.va_rent_demo;
		end;
      StateCode='VA';
      StateName='Virginia';
   end;
run;

libname json clear;
filename json clear;
proc sort data=backup.va_rent;
	by ID;
run;
proc sort data=backup.va_rent_demo;
	by ID;
run;
proc sort data=backup.va_rent_practice;
	by ID;
run;

proc copy in=backup out=cleanme;
run;


data _null_;
   file "&path/libnames.sas";
   put "%NRSTR(%%let) path=%superq(path);"/
       %tslit(libname cleanme %nrstr("&path/data");)/
       %tslit(libname backup  %nrstr("&path/data/backup");)/
       %tslit(libname clean  %nrstr("&path/data/clean");)/
       %tslit(options mrecall mautolocdisplay sasautos=(%nrstr("&path/autocall"),SASAUTOS);)//
       'title "Tables Used in This Course ";'/
		 'proc sql number;'/
 		 'select libname ''Library'''/
		 '      ,memname ''Table'''/
		 '      ,nlobs format=comma8. ''Obs Count'''/
       '      ,round(filesize/1000000,.1) ''File Size (MB)'''/
		 '   from dictionary.tables'/
		 '   where libname =''CLEANME'''/
		 '   order by 1,2'/
		 '   ;'/
		 'quit;'//
		 'title;footnote;'/
       ;
run;

%include "&path/libnames.sas"/source2;

