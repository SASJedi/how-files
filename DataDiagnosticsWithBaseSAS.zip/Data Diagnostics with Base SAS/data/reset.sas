﻿proc fedsql;
	drop table cleanme.va_rent_demo force;
	drop table cleanme.va_rent_practice force;
quit;
proc append base=cleanme.va_rent_demo
            data=backup.va_rent_demo;
run;
proc append base=cleanme.va_rent_practice
            data=backup.va_rent_practice;
run;
