﻿%macro rentPlots(dsn);
%local MSGTYPE;
%let MsgType=NOTE;
%if %SUPERQ(dsn)= ? %then %do;
%Syntax:
   %put &MsgType- ;
   %put &MsgType: &SYSMACRONAME documentation:;
   %put &MsgType- ;
   %put &MsgType-  Purpose:*Data Diagnostics in Base SAS workshop*;
   %put &MsgType-          Create Rent and Bedroom plots for all values;
   %put &MsgType-          of Type in one of the va_rents datasets.;
   %put &MsgType- ;
   %put NOTE: Uses the rentPlot macro to generate individual reports.;
   %put &MsgType- ;
   %put &MsgType- Syntax: %nrstr(%%)&SYSMACRONAME(dsn);
   %put &MsgType- ;
   %put &MsgType- dsn: Name of data set to process.;
   %put &MsgType- ;
   %put &MsgType- Examples: ;
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(cleanme.va_rents_demo);
   %put &MsgType- %nrstr(%%)&SYSMACRONAME(cleanme.va_rents_practice);
   %put &MsgType- ;
   %put &MsgType- ;
   %return;
%end; 
%if %SUPERQ(dsn)= %then %do;
  	%let MsgType=ERROR;
   %put &MsgType- ;
  	%put &MsgType: (&sysmacroname) Dataset name required.;
   %put &MsgType- ;
   %put &MsgType- ;
	%let dsn=practice;
%end;
proc sql noprint;
select distinct Type
	into :lvl1-
	from %superq(dsn)
;
quit;
%let numLvl=&sqlobs;

%do i=1 %to &numLvl;
	%if %superq(lvl&i) ne %then 
      %rentplot(%superq(lvl&i),%superq(dsn));
%end;
%mend rentPlots