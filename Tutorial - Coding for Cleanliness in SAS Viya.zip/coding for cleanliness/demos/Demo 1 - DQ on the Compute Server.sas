/* Identify existing duplicates */
title "Duplicates in the sasdata.prospects";
proc FedSQL number;
select Contact||','||Address||','||City||','||State as Entity
	  ,Count(*) as Count
	from sasdata.prospects
	group by 1
	having Count(*)  >1
;
quit;
/* %dqputloc(ENUSA,PARSEDEFN=0,short=1) */
/* Standardize the existing data */
data sasdata.prospects_std;
	set sasdata.prospects;
	select (dqidentify(Contact, 'Field Content')) ;
		when ('INDIVIDUAL') contact=dqstandardize(Contact,'Name') ; 
		when ('ORGANIZATION') contact=dqcase(Contact,'Proper (Organization)') ;
		otherwise contact=propcase(contact) ;
	 end;
	 Address=dqStandardize(Address,'Address');
	 City=dqstandardize(City,'City');
	 State=dqstandardize(State,'State/Province (Abbreviation)');
	 Phone=dqstandardize(Phone,'Phone');
;
run;

/* Identify existing duplicates */
title "Duplicates in standardized data (sasdata.prospects_std)";
proc FedSQL number;
select Contact||','||Address||','||City||','||State as Entity
	  ,Count(*) as Count
	from sasdata.prospects_std
	group by 1
	having Count(*)  >1
;
quit;

/* But what about John Q. Smith?? */
title "John Q. Smith duplication not detected";
proc FedSQL;
select ContactID,Contact,Address,City,State
	from sasdata.prospects_std
	where ContactID between 970 and 972
;
quit;

/* Behold - the power of match codes! */ 
title "Match codes could detect this duplication";
proc FedSQL;
select Contact,dqmatch(Contact,'Name')
	  ,Address,dqmatch(Address,'Address')
	  ,City,dqmatch(City,'City')
	  ,State,dqmatch(State,'State/Province')
	from sasdata.prospects_std
	where ContactID between 970 and 972
;
quit;

/* Ok - let's fix this data! */

/* Copy out the duplicates */
proc FedSQL ;
drop table duplicates FORCE;
create table duplicates as
/* Construct ClusterID by concatenating match codes for Name, Addressm, City, and State */
select dqmatch(Contact,'Name')||dqmatch(Address,'Address')||dqmatch(City,'City')||dqmatch(State,'State/Province') as ClusterID
	  ,* 
	from sasdata.prospects_std
	where dqmatch(Contact,'Name')||dqmatch(Address,'Address')||dqmatch(City,'City')||dqmatch(State,'State/Province')  
		in (select dqmatch(Contact,'Name')||dqmatch(Address,'Address')||dqmatch(City,'City')||dqmatch(State,'State/Province') as Entity
				from sasdata.prospects_std
				group by 1
				having Count(*)  >1)
	/* Sort into clusters, with the most complete record last in the cluster */
	order by ClusterID, Contact, State, City, ZIP, Address, HouseholdIncome, Phone;
quit;

/* Keep the last record in each cluster as the surviving record */
data survivors (drop=clusterID);
	set duplicates;
	by clusterID;
	if last.clusterID then output;
run;

/* Remove all duplicates from the orignal data */
proc FedSQL;
delete from sasdata.prospects_std
	where ContactID
		in (select ContactID
				from duplicates);
quit;

/* Then append the duplicate survivors */
proc append base=sasdata.prospects_std data=survivors;
run;

proc sort data=sasdata.prospects_std;
	by ContactID;
run;

/* Test to see if any of the prroblem records still have duplicates in the final data */
title "No two names are alike here, so duplicate records no longer exist"; 
proc FedSQL;
select *  
	from sasdata.prospects_std
	where ContactID
		in (select ContactID
				from duplicates);
quit;
title;


