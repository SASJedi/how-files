/* Extracting Data from poorly formatted text */
/* Preview the txt file */
filename rawinfo "&path/data/rawinfo.txt";
title "Mama mia, that's some dirty data!";
data _null_;
	infile rawinfo;
	file print;
	input;
	put _infile_;
run;

/* Extracting information using standard SAS code */
data emails;
	infile rawinfo _infile_=rawdata;
	input;
	_atsign=find(rawdata, '@');
	_start=find(rawdata, ',', -_atsign)+1;
	_stop=find(rawdata, ',', _atsign);
	Email=lowcase(substr(rawdata, _start, _stop-_start));
	drop _:;
run;
title "Emails extracted and standardized using find, substr, and lowcase";
title2 "4 lines of code to retrieve one value";
proc print; run;

/* But how do you extract the rest? */
/* Extracting information using SAS Data Quality */
/* What extraction definitions are available? */
data _null_;
	num=dqLocaleInfoList('extraction', 'ENUSA');
run;

/* What tokens are available in the extraction definitions? */
data _null_;
	contactTokens=dqExtInfoGet('Contact Info','ENUSA');
	put contactTokens=;
	brandTokens=dqExtInfoGet('Brand/Manufacturer','ENUSA');
	put brandTokens=;
	productTokens=dqExtInfoGet('Product Attributes','ENUSA');
	put productTokens=;
run;

/* Let's use the Contact Info definition to extract our data */
data EmailAndMore;
	infile rawinfo _infile_=rawdata;
	input;
	/* Extract the tokens from the raw data only once for efficiency */
	_tokens=dqextract(rawdata,'Contact Info','ENUSA');
	drop _:;
    /* Get each data value */
	Name=dqExtTokenGet(_tokens
								,'Name', 'Contact Info', 'ENUSA');
	Organization=dqExtTokenGet(_tokens,'Organization', 'Contact Info', 'ENUSA');
	Address=dqExtTokenGet(_tokens
								,'Address', 'Contact Info', 'ENUSA');
	Email=dqExtTokenGet(_tokens
								,'E-mail', 'Contact Info', 'ENUSA');
	Phone=dqExtTokenGet(_tokens
								,'Phone', 'Contact Info', 'ENUSA');
run;
title "Data extracted using DQ functions";
title2 "6 lines of code to retrieve all 5 values";
proc print; run;
title;


/* Let's also standardize the extracted data */
data _null_;
	num=dqLocaleInfoList('standardization', 'ENUSA');
run;

data EmailAndMore;
	infile rawinfo _infile_=rawdata;
	input;
	/* Extract the tokens from the raw data only once for efficiency */
	_tokens=dqextract(rawdata,'Contact Info','ENUSA');
	drop _:;
    /* Get each data value and standardize the text */
	Name=dqstandardize(dqExtTokenGet(_tokens
								,'Name', 'Contact Info', 'ENUSA'),'Name');
	Organization=dqcase(dqExtTokenGet(_tokens
								,'Organization', 'Contact Info', 'ENUSA'),'Proper (Organization)');
	Address=dqStandardize(dqExtTokenGet(_tokens
								,'Address', 'Contact Info', 'ENUSA'),'City - State/Province - Postal Code');
	Email=lowcase(dqExtTokenGet(_tokens
								,'E-mail', 'Contact Info', 'ENUSA'));
	Phone=dqstandardize(dqExtTokenGet(_tokens
								,'Phone', 'Contact Info', 'ENUSA'),'Phone');
run;
title "Data extracted and standardized using DQ functions";
title2 "Still only 6 lines of code to retrieve all 5 values";
proc print; run;
title;

