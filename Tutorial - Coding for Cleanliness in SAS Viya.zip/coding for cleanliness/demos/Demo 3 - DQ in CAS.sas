/******************************************************************************
 - SASDATA and WORK librefs replaced with CASUSER 
 - PROC FedSQL uses the sessref= option & "number" is no longer effective.
******************************************************************************/
/* Identify existing duplicates */
title "Duplicates in the casuser.prospects";
proc FedSQL sessref=conn number;
select Contact||','||Address||','||City||','||State as Entity
	  ,Count(*) as Count
	from casuser.prospects
	group by 1
	having Count(*)  >1
;
quit;
/* %dqputloc(ENUSA,PARSEDEFN=0,short=1) */
/* Standardize the existing data */
data casuser.prospects_std;
	set casuser.prospects;
	select (dqidentify(Contact, 'Field Content')) ;
		when ('INDIVIDUAL') contact=dqstandardize(Contact,'Name') ; 
		when ('ORGANIZATION') contact=dqcase(Contact,'Proper (Organization)') ;
		otherwise contact=propcase(contact) ;
	 end;
	 Address=dqStandardize(Address,'Address');
	 City=dqstandardize(City,'City');
	 State=dqstandardize(State,'State/Province (Abbreviation)');
	 Phone=dqstandardize(Phone,'Phone');
;
run;

/* Identify existing duplicates */
title "Duplicates in standardized data (casuser.prospects_std)";
proc FedSQL sessref=conn  number;
select Contact||','||Address||','||City||','||State as Entity
	  ,Count(*) as Count
	from casuser.prospects_std
	group by 1
	having Count(*)  >1
;
quit;

/* But what about John Q. Smith?? */
title "John Q. Smith duplication not detected";
proc FedSQL sessref=conn ;
select ContactID,Contact,Address,City,State
	from casuser.prospects_std
	where ContactID between 970 and 972
;
quit;

/* Behold - the power of match codes works in CAS, too! */ 
title "Match codes could detect this duplication in CAS, too!";
proc FedSQL sessref=conn ;
select Contact,dqmatch(Contact,'Name')
	  ,Address,dqmatch(Address,'Address')
	  ,City,dqmatch(City,'City')
	  ,State,dqmatch(State,'State/Province')
	from casuser.prospects_std
	where ContactID between 970 and 972
;
quit;

/* Ok - let's fix this data! */

/* Construct ClusterID by concatenating match codes for Name, Addressm, City, and State */
proc FedSQL sessref=conn;
drop table casuser.clusterIDs force;
create table casuser.clusterIDs as
	select dqmatch(Contact,'Name')||dqmatch(Address,'Address')||dqmatch(City,'City')||dqmatch(State,'State/Province') as clusterID
	       ,count(*) as Counts
		from casuser.prospects_std
		group by 1
;
quit;

proc FedSQL sessref=conn;
drop table casuser.duplicates force;
create table casuser.duplicates as
	select p.*, ClusterID,counts
		from casuser.prospects_std as p
		  inner join
			  casuser.clusterIDs as c
			on c.clusterID=dqmatch(Contact,'Name')||dqmatch(Address,'Address')||dqmatch(City,'City')||dqmatch(State,'State/Province')
;
quit;

/* Pick the last record in the cluster as the surviving record */
data casuser.prospects_final (drop=clusterID counts) /sessref=conn;
	set casuser.duplicates;
	by ClusterID Contact State City ZIP Address HouseholdIncome Phone;
	if last.clusterID then output;
run;

/* Check out the results */
proc FedSQL sessref=conn ;
select p.*  
	from casuser.prospects_final as p
	inner join
	casuser.duplicates as d
	on p.ContactID=d.ContactID
	where counts>1
	order by p.contact, p.address, p.city, p.state
;
quit;


