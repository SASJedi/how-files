data sasData.names;
   length Name $50 Locale $5;
   infile datalines dsd dlm='|';
   input name:$UPCASE. locale: $UPCASE.;
datalines;
Karl Wolfgang von Müller|DEDEU
Bayerische Motoren Werke AG|DEDEU
Jane Q. Doe|ENUSA
SAS Institute, Inc.|ENUSA
José Maria Pereira da Silva|PTBRA
Embraer S.A.|PTBRA
;
