data sasData.Examples;
  infile datalines dsd dlm='|' truncover;
  input Contact:$50. Address:$50. City:$50. State:$15. ZIP:$50.;
datalines4;
Mr. John Q. Smith|719 Madison Ave|Cary|NC|27513
Johnny Smyth|719 Madison Avenue|Cary|North Carolina|27513
smith, jon q. |719 madisun av.|cary|nc|27513
;;;;
