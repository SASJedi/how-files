data sasData.Prospects;
  infile datalines dsd truncover;
  input ContactID Contact:$50. Address:$50. City:$50. State:$50. ZIP:$50. HouseholdIncome:32. Phone:$50.;
datalines4;
572,Mark Abbott,719 Madison Ave,Cary,NC,27513,61818,919-531-7750
573,Mark Abbott,112 Meadow Run,Knightdale,NC,27545,61838,919-266-3111
574,Mark & Julie Abbott,4706 Hollister Dr,Greensboro,NC,27407,61859,336-286-5747
575,Mark A Abbott,3220 Old House Cir,Charlotte,NC,28212,61880,704-596-5696
576,Mary G Abbott,7074 Ed Willis Rd,Vale,NC,28168,61901,704-276-9977
577,May R Abbott,903 S Carolina Ave,Henderson,NC,27536,61922,252-492-5914
578,Melissa Abbott,1013 E 10th St,Lumberton,NC,28358,61942,910-738-8571
579,Michael Abbott,5207 Sequoia Rd,Fayetteville,NC,28304,61963,910-488-5753
580,Michael D Abbott,1140 4th Creek Landing Dr,Statesville,NC,28677,61984,704-873-0555
581,Michael J Abbott,413 Ramblewood Dr,Raleigh,NC,27609,62005,919-870-9990
582,N Abbott,7703 Radin Rd,Waxhaw,NC,28173,62026,704-843-1897
583,Nancy Ann Abbott,124 Wood Ct,Winston Salem,NC,27107,62046,336-703-1170
584,Nickey Abbott,7100 Riverwind Dr,Spring Lake,NC,28390,62067,910-436-4113
585,Noel W Jr Abbott,2 Hickory Knoll Ct,Greensboro,NC,27407,62088,336-286-5771
586,Norma Abbott,752 NE Market St,Reidsville,NC,27320,62109,336-349-5674
587,O C Abbott,209 Smoketree Way,Louisburg,NC,27549,62130,919-496-3314
588,O Vance Abbott,109 Ellsworth Pl,Cary,NC,27511,62150,919-606-1978
589,O Wayne Abbott,3917 US Highway 64 W,Apex,NC,27502,62171,919-363-2171
590,P A Abbott,205 Rosebrooks Dr,Cary,NC,27513,62192,919-467-9629
591,P E Abbott,3923 Colorado Ave,Durham,NC,27707,62213,919-598-5693
592,P W Abbott,411 Charles St,Henderson,NC,27536,62234,252-492-5913
593,Paige M Abbott,2106 E 4th St,Greenville,NC,27858,62254,252-752-6988
594,Pat Abbott,407 Cottage Ln,Durham,NC,27713,62275,919-598-5703
595,Patricia Russell Abbott,139 Frye Bridge Rd,Clemmons,NC,27012,62296,336-766-5690
596,Patrick Abbott,3007 Cottage Pl,Greensboro,NC,27455,62317,336-286-5765
597,Paul Abbott,338 N Sunset Dr,Asheboro,NC,27203,62338,336-879-7283
598,Paul Abbott,1401 Spaniel Ct,Wilmington,NC,28405,62358,910-251-1472
599,Paul J Abbott,544 S Cooper Dr,Henderson,NC,27536,62379,252-492-5915
600,Paula Abbott,4600 Country Club Rd,Morehead City,NC,28557,64480,252-808-2288
601,Pauline H Abbott,333 Clearwater Lake Rd,Mt Holly,NC,28120,64501,704-827-2629
602,Pete Abbott,296 Fire Tower Rd,Ellerbe,NC,28338,64522,910-652-5703
603,Phil Abbott,1025 Traders Trl,Wake Forest,NC,27587,64542,919-556-7844
604,Piper Abbott,16 Pebblebrook Dr,Arden,NC,28704,64563,828-633-8452
605,Preston Abbott,3901 Old US Highway,Pelham,NC,27311,64584,336-939-9123
606,R Abbott,1601 E Holly St,Goldsboro,NC,27530,64605,919-735-5735
607,R B Abbott,7099 US Highway 301 S,Four Oaks,NC,27524,64626,919-963-7984
608,R M Abbott,3524 Draper Ave,Charlotte,NC,28205,64646,704-596-5697
609,R M Abbott,230 S Church St,Winterville,NC,28590,64667,252-756-8065
610,R M Jr Abbott,6716 Piedmont Pl,Wilmington,NC,28405,64688,910-251-1471
611,R P Abbott,132 British Lake Dr,Greensboro,NC,27410,64709,336-286-5777
612,Rachel H Abbott,4512 Lawndale Dr,Greensboro,NC,27455,64730,336-286-5776
613,Randy Abbott,3404 Overton Dr,Greensboro,NC,27408,64750,336-286-5767
614,Randy Abbott,1144 Vestal St,Yadkinville,NC,27055,64771,336-679-3147
615,Ray & Beverly Abbott,3923 Colorado Ave,Durham,NC,27707,64792,919-598-5729
616,Raymond Abbott,665 Roanoke Ave,Henderson,NC,27536,64813,252-492-5910
617,Raymond Abbott,801 Wakefield Ave,Henderson,NC,27536,64834,252-492-5916
618,Raymond H Abbott,2820 Blanche Dr,Burlington,NC,27215,64854,336-792-4101
619,Richard Abbott,2305 Cynthia Dr,Durham,NC,27704,64875,919-598-5734
620,Richard Abbott,5620 Mount Pleasant Rd,Rockwell,NC,28138,64896,704-279-7794
621,Ricky Abbott,612 Duke St,Reidsville,NC,27320,64917,336-349-9409
622,Rita Abbott,39 Owl Branch Rd,Cherokee,NC,28719,64938,828-497-7486
623,Robert Abbott,405 N Country Club Dr,Oxford,NC,27565,64958,919-693-9677
624,Robert Abbott,5504 Fieldstone Dr,Raleigh,NC,27609,64979,919-870-9967
625,Robert Abbott,1106 W Waddell St,Selma,NC,27576,65000,919-965-0111
626,Robert C Abbott,625 Burning Tree Rd,Pinehurst,NC,28374,65021,910-295-1083
627,Robert E Abbott,1106 Murphy Rd,Henderson,NC,27536,65042,252-492-5923
628,Robin Abbott,99 Cedar Dr,Lenoir,NC,28645,65062,828-754-4867
629,Ron Abbott,106 Regent Pl,Chapel Hill,NC,27514,65083,919-942-1235
630,Ronald Abbott,1321 S Lake Park Blvd,Carolina Beach,NC,28428,65104,910-458-7584
631,Ronald T Abbott,601 Shadywood Ln,Raleigh,NC,27603,65125,919-870-9971
632,Rosalyn Abbott,212 S Byrd St,Eden,NC,27288,65146,336-627-5736
633,Roy J Abbott,209 Morris Dr,Atlantic,NC,28511,65166,(252) 656-0307
634,Royal K Abbott,59 Westall Ave,Asheville,NC,28804,65187,828-633-4076
635,Ruth Mrs Abbott,411 Charles St,Henderson,NC,27536,65208,252-492-5921
636,S Abbott,4408 Crystal Lake Dr,Summerfield,NC,27358,65229,336-643-4563
638,S S Abbott,513 Mill Rd,Goldsboro,NC,27534,65270,919-735-5733
639,S W Abbott,7555 Pine Hall Rd,Belews Creek,NC,27009,65291,336-378-4572
640,Samuel & Opal Abbott,3092 Chandlers Mill Rd,Pelham,NC,27311,65312,336-939-9046
641,Samuel L Abbott,4036 Yarborough Ave,Winston Salem,NC,27106,65333,336-703-1164
642,Sandy Robert Abbott,124 N Canterbury Rd,Charlotte,NC,28211,65354,704-596-5695
643,Sarah Abbott,360 Wood Rd NW,Taylorsville,NC,28681,65374,828-632-4633
644,Scott Abbott,4816 Wrightsville Ave,Wilmington,NC,28403,65395,910-251-1486
645,Scott L Abbott,4813 Atlantis Ct,Wilmington,NC,28403,65416,910-251-1573
646,Scott Sr Abbott,4977 Rifle Range Rd,Conover,NC,28613,65437,828-465-7458
647,Sefton & Jean Abbott,514 Blue Ridge Rd,Black Mountain,NC,28711,65458,828-484-4029
648,Stacey Abbott,755 Boddie St,Henderson,NC,27536,65478,252-492-5918
649,Stephen Abbott,2648 Hill Ln,Gastonia,NC,28054,65499,704-823-1435
650,Stephen & Beth Abbott,124 Shade Tree Ct,Gastonia,NC,28056,65520,704-827-4555
651,Steve Abbott,6500 Deermont Ct,Charlotte,NC,28211,65541,704-596-5694
652,Steve (Fax) Abbott,6500 Deermont Ct,Charlotte,NC,28211,65562,704-596-5693
653,T Abbott,264 Tanasee Gap Rd,Brevard,NC,28712,65582,828-884-7832
654,Ted Abbott,4324 Drifter Dr,Charlotte,NC,28227,65603,704-596-5691
655,Ted & Shelia Abbott,85 Pensacola Ave,Arden,NC,28704,65624,828-633-9357
656,Thelma L Abbott,306 N Regan St,Greensboro,NC,27401,65645,336-286-5757
657,Theo Abbott,2024 Saint John St,Charlotte,NC,28216,65666,704-596-5689
658,Thomas D MD Abbott,12200 N 150 Hwy,Winston Salem,NC,27100,65686,336-703-1151
659,Thomas R Abbott,3430 Forest Ln,Pfafftown,NC,27040,65707,336-945-3248
660,Thomas S Abbott,106 SW 14th St,Oak Island,NC,28465,65728,910-278-7421
661,Thomas W Abbott,123 Southern Ave,Henderson,NC,27536,65749,252-492-5927
662,Timothy C Abbott,5684 Teakwood Rd,Hickory,NC,28602,65770,828-328-2446
663,Tomi Abbott,111 Sandridge Way,Waynesville,NC,28786,65790,828-456-5850
664,Tommy W Abbott,2457 Mccraw Rd,Mooresboro,NC,28114,65811,828-657-3675
665,Tonya Abbott,3222 Octavia St,Raleigh,NC,27606,65832,919-870-9969
666,Trace Abbott,9211 Pebble Creek Way,Charlotte,NC,28269,65853,704-596-5690
667,Troy Abbott,119 Halifax Rd,Cherry Point,NC,28533,65874,252-636-9665
668,V A Jr Abbott,1101 Oriental Ave,Kinston,NC,28501,65894,252-527-0313
669,V L Abbott,8223 Larkhaven Rd,Charlotte,NC,28216,65915,704-596-5692
670,W A Abbott,703 Circle Dr,New Bern,NC,28562,65936,252-638-2973
671,W E Abbott,211 Crestridge Dr,Waynesville,NC,28786,65957,828-456-5849
672,Wade T Abbott,1689 Ed Little Rd,Creston,NC,28615,65978,336-385-6995
673,Walter Abbott,213 Duck Rd,Southern Shores,NC,27949,65998,
674,Wayne Abbott,3622 Abercromby Dr,Durham,NC,27713,66019,919-598-5718
675,Willard G Abbott,355 Newgate St,Lumberton,NC,28358,66040,910-738-7983
676,William Abbott,517 Friendship Dr,Matthews,NC,28105,66061,704-844-8697
677,William & Debbie Abbott,605 5 Mile Rd,Richlands,NC,28574,0,910-324-3908
885,WIlliam Macaluso,352 Bonniewood DRIVE,Cleveland,OH,,49878,
886,Joe Blasiole,3111 Hunters Bluff Dr,Raleigh,NC,27606,49899,
888,Bobby Walton,118 Englefield drive,Kings,N.Y.,11225,52021,
889,Mary Kate Blondino,118 Grande Classic Way,Dallas,TX,75149,52042,
890,Tim Witheft,152 Guy Peart Rd,Alexandria,LA,71302,52062,
891,Chris J. Mollmann,165 Crossgar Court,Nueces,TX,78412,52083,
894,Mike Striebel,409 Brook Creek Dr,Cary,NC,27513,52146,
895,Cindy Endrusick,1043 Red Chalk rd.,Erin,NY,14838,52166,
896,Nikki Long,2255 Gadland CT,Santa Clara,CAL,95120,52187,
897,Cynthia Mitofsky,27 Cameo Lane,Chillicothe,OH,4560,52208,
898,Bill Shalak,Box 487 27 Cedar Ln,Spring City,TN,37381,52229,
899,Susan Dylypiw,3807 Avenida del Sol,Studio Cty.,CA,91604,52250,
900,Kathy Mucugu,3579 Holmgren St,Charleston,S.C.,29466,52270,
901,Joe Lamanna,55 CHURCH ST,NY,New York,,52291,
902,Charles B. Walker,422 Dice Drive,Merrimack,NH,3301,52312,
903,Toney Bullock,5248 Baywood Forest Drive,Knightdale,NC,27545,52333,
904,Elizabeth Burgoin,4509 College street,Jackson,OR,97535,52354,
905,Sandra Day,6040 Allsdale Dr.,Raleigh,NC,27617,52374,
906,Pam Williams,1321 South Dawson St,Seattle,WA,98118,52395,
907,Kelly Owenby,56 Hollowgate Rd,Hillsborough,FL,33527,52416,
908,Jenny Arria,5600 Lakeside Dr,Palm Beach,FL,33407,52437,
909,Judy Yanulevich,7190 State Road 113,Dane,WI,53529,52458,
910,Robert James Rehguate,623 Forest Landing Dr.,Barrow,GA,30680,52478,
911,Tara Pardue,623 Forest Lawn Court,Los Angeles,CA,90011,52499,
912,Becky Asper,7179 Buckingham Rd,Augusta,VA,24482,52520,
915,Judy Tobia,7803 Hollyhock LANE,Spokane,Wash.,99216,52582,
918,Jennifer Inscoe,782 Kaplan Dr,Green,WI,53566,52645,
922,Indie Payne,7840 Glenwood Ave,Dallas,Texas,75038,52728,
933,Joe Sivon,8465 Allison Dr,Harris,TX,77036,52957,
934,Sara Degraffenreid,8467 Batterhayes Rd,Mercer,W. Virginia,24737,52978,
935,Patty Minor,847 Blackwolf Run LANE,Carbon,PA,18235,52998,
937,Bobbi Smith,8810 Chiselhurst Way,Fauquier,VA,22734,53040,
939,Ed Parker,8832 Hillsborough street,Mobile,AL,36617,53082,
940,Lynn Ann Hilty,921 King William Rd,Wyoming,WV,24874,53102,
941,Anna Willings,9212 Glenthorne Drive,San Mateo,CA,94303,53123,
942,Jeraldine Stanaski,949 Laodicea Dr,Laramie,WY,82072,53144,
944,Anna Lynn Tomassi,9652 Brentwood Rd,Orange,FL,32817,53186,
946,Najma Hix,9658 Dinwiddie Ct,Blair,PA,16648,53206,
947,Larry McQueen,987 Langwood Dr,St. Louis (City),MO,63106,53227,
948,Bob Gillyard,9870 Fanny Brown Rd,Adams,MS,39120,53248,
952,Donny Kuczynski,988 Davie street,Queens,NY,11001,52000,
953,Jodeesha Sizemore,988 Golden str,San Diego,CA,92139,52021,
954,Curly Sublaban,988 Holleman St,Los Angeles,CA,90230,52042,
956,Rob Wiseley,9887 Brandon Mill Cir,Middlesex,MA,2155,52083,
958,Balinda Tatem,989 Brighton road,Jasper,IN,47978,52125,
961,Karla Hall,989 Country Lane,Bernalillo,NM,87107,52187,
963,Bob Inghram,989 Glen Echo LANE,Kings,N. York,11236,52229,
965,Caryl Saba,989 Hunting Ridge road,Orange,CA,92804,52270,
966,Walter Wilklow,989 Lantana Cir,Wayne,IN,47327,52291,
967,Dietz Martindale,9894 Kennebec rd.,Tarrant,TX,76116,52312,
969,Kris Mangual,9898 Glen Mavis Court,Morgan,OH,43758,52354,
881,Cynthia Aaron,5400 Pullytown Road.,Zebulon,NC,27597,44595,919-404-1120
882,Fidelity Fed. Bank,Box 429,Woodfields,OH,43793,39749,306-312-4292
883,JP Call,3 Bridges Cir,Raleigh,NC,27613,34800,919-342-6920
1,Michelle Francis Wan,4000 East Sky Harbor blvd.,Chesterfield,MO,63005,39541,426-758-4180
2,E. Fusco,2617 Ramsey Rd #8,Herndon,VA,22070,39562,500-881-3331
3,Florence Dalton,1891 County Road 30,Kitts Hill,OH,45645,39582,466-252-1201
4,Earl Rigdon,17445 Drymill Road,Leesburg,Virginia,20175,39603,338-157-8776
5,Mr. Doug Doty,406 McClure Circle,Minneapolis,MN,55431,39624,850-323-7265
6,Rain Bird Corporate Services Inc.,832 Brooke Rd,Virginia Beach,VA,23454,39645,549-354-2416
7,TRW SPACE & DEFENSE,4624 RHRORIE RD,ATHENS,OH,45701,39666,587-845-8069
8,Anthony Lemberger,River View rd Ext,Lexington,N.C.,27292,39686,336-243-1073
9,Joe Rochford,"2800 Woodlawn Dr, Apt 23B",Ballwin,MO,63011,3999707,721-144-7436
10,Denise McNath,1215 N Caldwell St,New Haven,Ct,06516,39728,660-469-0704
11,FIDELITY FEDERAL BANK,BOX 429,WOODFIELDS,OH,43793,39749,306-312-4292
12,Sean Nugent,1993 Ernsford Dr,St. Louis,MO,63114,39770,495-764-8564
13,Sidney Tretter,161 Northfork Rd,Lima,Ohio,45801,39790,419-566-4322
14,Marina Tennis-Smith,2421 Patterson Rd # 3,Kettering,OH,45420,39811,814-489-6429
15,Shannon Mazo,1515 Lord Ashley Dr,St. Louis,MO,63128,39832,956-586-4147
16,Mishelle Wan,4000 E Sky Harbor Blvd.,Chesterfield,MO,63005,39541,426-758-4180
17,Phillip Gerstle,Po Box 13507,Skokie,Illinois,60076 2999,39874,360-681-2934
18,Rob Rubenstein,3939 Ruffin Rd,Saint Louis,MO,63021,39894,297-073-4204
19,Gwen O'Story,2120 Raven Glass Pl,Philadelphia,PA,19178-4955,39915,284-565-7463
20,CBG,200 Chestnut Avenue,Warren,OH,44483,39936,612-921-7653
21,Pat Duffey,12960 Randomwood Drive,Laurinburg,NC,28352,39957,910-424-7558
22,Motorola Inc. - Semiconductor Div,507 S High St,Woodsfield,OH,43793,39978,398-684-7205
23,Cal. State Polytechnic Univ.,3540 Wilshire Blvd,Redwood Shores,CA,94065,39998,902-861-5100
24,Johnathon Michael Soon,239 N Edgeworth St,St. Louis,Missouri,63104,40019,615-005-6993
25,Rebecca Golub,112 Chaunti Cleer Road,Columbia,SC,29223,40040,443-778-6033
26,Ashley Bey,P.O. Box 6239,N. Ridgeville,OH,44039,40061,271-475-5054
27,KATHY LAPP,955 DEER RUN,CENTERVILLE,OH,45409,40082,718-922-0353
28,Queen of Angels Medical Center,20779 Silver Thistle Court,Ashburn,VA,20147,40102,279-648-0144
29,NORTHROP CORP,BOX 218,HOSKINS,NE,68740,40123,600-732-2269
30,Citrus College,5024 Fairbanks Way,Sunnyvale,CA,94089,40144,618-121-6649
31,Sharon Mandelbaum,3540 Wilshire Blvd,Redwood Shores,Calif.,94065,40165,902-861-5137
32,Abigail Sargent,4211 S Rushford St,Palo Alto,CA,94303,40186,860-952-3496
33,Lou Samual VanVleet,777 S. Harbor Blvd.,Bellevue,WA,98006-1800,40206,357-989-4735
34,Phillip Gerstle,PO Box 13507,Skokie,IL,60076-2999,40227,360-681-2934
35,Rob CharlesRubenstein,3939 Ruffin Rd,St Louis,MO,63021,40248,297-073-4204
36,Margaret Muench,3001 W Mission Rd Ste A,Dallas,TX,75247,40269,883-271-9095
37,Jose Rochford,"2800 Woodlawn Dr, Apt 23B",Ballwin,MO,63011,40290,721-144-7436
38,K SEKERES,5541 CENTRAL AVE,MARLOW,NH,03456,40310,991-312-5527
39,Andre Hulbert,5024 Fairbanks Way,Sunnyvale,CA,94089,40331,618-121-6649
40,Ashly Bey,Box 6239,N. Ridgeville,OH,44039,40352,271-475-5054
41,Gary Stratman,5153 Camino Ruiz,Sunnyvale,California,94086,40373,350-964-1700
42,Michelle F. Wan,4000 East Sky Harbor Blvd,Chesterfield,MO,63005,40394,426-758-4180
43,Cindy Prentiss,"515 E. Broad St., Ste. 12",St Louis,MO,63146,40414,949-161-1908
44,Jonathan McGee,4900 Rivergrade Rd,Bannockburn,IL,60015,40435,843-042-5960
45,Miranda Andre,510 LightHouse Ave.,Cupertino,CA,95014,40456,620-959-5034
46,Johnathon Soon,239 N Edgeworth St,St Louis,MO,63104,40477,615-005-6993
47,Pat Pietron,4305 Central Ave West,Orem,UT,84058,40498,456-854-5248
48,Denise Nath,1215 N Caldwell St,New Haven,CT,06516,40518,660-469-0704
49,Kristina Radley,4430 E Greensboro Chapel Hill Rd,Kansas City,MO,64141 6267,40539,979-842-2568
50,Shannon Mazo,1515 Lord Ashley Dr,St. Louis,MO,63128,40560,956-586-4147
51,CATHY LAPP,"4400 NC HWY, PO BOX 44",ST LOUIS,MO,63134,40581,718-922-0353
52,Sean Nugent,1993 Ernsford Dr,St. Louis,MO,63114,40602,495-764-8564
53,Ed Fusco,2617 Ramsey Rd #8,Herndon,VA,22070,40622,500-881-3331
54,Marina L. Tennis,2421 Patterson Road Box 3,Kettering,Ohio,45420,39811,814-489-6429
55,Dougglas Doty,406 Mcclure Cir,Minneapolis,Minnesota,55431,40664,850-323-7265
56,Sidney Tretter,161 Northfork Rd,Lima,OH,45801,40685,419-566-4321
57,Eric Einhorn,23 S Saunders Rd,Hutchins,KS,67504-5282,40706,530-406-2382
58,Gwen Story,2120 Raven Glass Pl,PHILADELPHIA,PA,19178-4955,40726,284-565-7463
59,Jessica Macias,5230 Walnut Grove Ln,Sherman,TX,75090-4440,40747,738-818-2196
60,David Grassi,824 Valerie Dr Unit 30,Pomona,Ca.,91768,40768,806-295-2544
61,Sharon Mandelbam,3540 Wilshire Blvd.,Redwood Shores,CA,94065,40789,902-861-5137
62,Louis Voss,777 S. Harbor Blvd,Bellevu,Washington,98006-1800,41,357-989-4735
63,Phillip Gerstle,PO Box 13507,Skookie,IL,60076-2999,40830,360-681-2934
64,Robert Rubenstein,3939 Ruffin Road,Saint Louis,MISSOURI,63021,40851,297-073-4204
65,Kurt Sekeres,5541 Central Ave,Marlow,NH,03456,40872,991-312-5527
66,Ashley Bay,P.O. 6239,North Ridgeville,Ohio,44039,40893,271-475-5054
67,Cindy Prentiss,"515 E. Broad St., Suite. 12",Saint Louis,MO,63146,40914,949-161-1908
68,Jonathan McGee,4900 Rivergrade Rd,Bannockburn,IL,60015,40934,843-042-5960
69,Johnathon Soon,239 N Edgeworth Sreet,St Louis,MissoUri,63104,40955,615-005-6993
70,Patrick Pietron,4305 Central Avenue West,Orem,Utah,84058,40976,456-854-5248
71,Kristina Radley,4430 E Greensboro Chapel Hill Rd,Kansas City,MO,64141 6267,40997,979-842-2568
72,Shannon Mazo,1515 Lord Ashley Dr,SAINT. Louis,Missouri,63128,41018,956-586-4147
73,Cathy Lap,"4400 NC Highway, PO Box 44",ST. LOUIS,MO,63134,41038,718-922-0353
74,Sean Nugent,1993 Ernsford Dr,St. Louis,MO,63114,41059,495-764-8564
75,E Fusco,2617 Ramsey Rd Suite 8,Herndon,VIRGINIA,22070,41080,500-881-3331
76,Sam Harleen,102 Echo Glen Dr,St. Charles,MO,63301,41101,731-887-4557
77,Douglas Doty,406 Mcclure Circle,Minneapolis,MN,55431,41122,850-323-7265
78,Sidney Treter,161 Northfork Rd,Lima,OH,45801,41142,419-566-4321
79,Erick Einhorn,23 S Saunders Rd,Hutchins,KS,67504-5282,41163,530-406-2382
80,Jessica Macias,5230 Walnut Grove Lane,Sherman,Texas,75090-4440,41184,738-818-2196
81,Dave Grassi,824 Valerie Dr Unit 30,Pomona,California,91768,41205,806-295-2544
82,Frank Johns Atty A,239 N Edgeworth St,Greensboro,NC,27401,41226,336-286-5759
83,Graham A,4305 Central Ave,Charlotte,NC,28205,41246,704-596-5725
84,Thek A,1215 N Caldwell St,Charlotte,N.C.,28206,41267,704-596-5724
85,E Aabel,4430 E Greensboro Chapel Hill Rd,Graham,NC,27253,41288,336-570-1874
86,Dale R Aagaard,1515 Lord Ashley Dr,Sanford,NC,27330,41309,919-776-1753
87,T K Jr Duke & Villette Ducray Aageson,4400 Nc Highway,Willard,nc,28478,41330,
88,E M Aaker,1993 Ernsford Dr,Winston Salem,NC,27103,41350,336-703-1166
89,Ayosha Aal-Anubia,2617 Ramsey Rd,Raleigh,NC,27604,41371,919-870-9958
90,Edward Reza Aalam,102 Echo Glen Dr,Winston Salem,NC,27106,41392,336-703-1156
91,Elsie B Aalam,406 Mcclure Cir,Castle Hayne,NC,28429,41413,910-274-3391
92,Leola Aalberg,161 Northfork Rd,Franklin,NC,28734,41434,828-349-8971
93,Walter Aalberg,163 Northfork Rd,Franklin,NC,28734,41454,828-349-0285
94,K Shelley A Aalfs,2120 Raven Glass Pl,Raleigh,NC,27612,41475,919-870-9959
95,Tracy Aalsma,5230 Walnut Grove Ln,Charlotte,NC,28227,41496,704-596-5723
96,Omar M Aamar,824 Valerie Dr,Raleigh,NC,27606,41517,919-870-9960
97,Tom & Michelle Aamland,7563 Erect Rd,Seagrove,NC,27341,41538,336-873-7934
98,John C Aamodt,130 Turley Falls Rd,Hendersonville,NC,28739,41558,828-685-8694
99,Doug Doti,406 McClure Circle,Minneapolis,Minn.,55431,40664,850-323-7265
100,Elizabeth Aan,3601 Wheaton Pl,Raleigh,NC,27609,43680,919-870-9961
101,D Aanonsen,34 Ridgedale Rd,Candler,NC,28715,43701,828-667-1795
102,Rita Aanonsen,625 Hendersonville Rd,Asheville,NC,28803,43722,828-225-7723
103,Roy Aanonsen,4032 Grey Fox Ct,Olivia,NC,28368,43742,
104,J Aanstad,221 Harmon Ct,Winston Salem,NC,27106,43763,336-703-1155
105,J V Aanstoos,311 Homestead Dr,Cary,NC,27513,43784,919-467-7342
106,Gregory C Aardal,778 Old Zebulon Rd,Wendell,NC,27591,43805,919-365-8438
107,L Aardal,433 Wall St,Wendell,NC,27591,43826,919-365-8439
108,Jack Stuart Aardema,6 Shore Dr,Wrightsville Beach,NC,28480,43846,910-256-8184
109,Rob E. Rubenstein,3939 Ruffin Rd,St Louis,MO,63021,40851,297-073-4204
110,Sharon M Aardsma,902 Park Ridge Rd,Durham,NC,27713,43888,919-598-5715
111,A W Aarhus,210 Sherrill Ave,Oak Island,NC,28465,43909,910-278-8403
112,A W Aarhus,1956 Bramblewood Trl,Pfafftown,NC,27040,43930,336-945-3456
113,Rob Rubensteen,3939 Ruffin Rd #107-B,St Louis,MO,63021,40851,297-073-4204
114,Ingeborg Aarninik,6925 Queensberry Dr,Charlotte,NC,28226,43971,704-596-5722
115,Mr. Doug M. Doty,406 McClure Cir.,Minneapolis,MN,55431,40664,850-323-7265
116,I S Aarnink,6925 Queensberry Dr,Charlotte,NC,28226,44013,704-596-5721
117,Chris & Jeanne Aaroe,312 Jackson St,Greensboro,NC,27403,44034,336-286-5770
118,Leonard G Aaroe,432 Loblolly Dr,Vass,NC,28394,44054,
119,A Dwayne Maj Aaron,410 Edinburgh Dr,Fayetteville,NC,28303,44075,910-488-5749
120,Amelia B Aaron,119 West Ave,Hamlet,NC,28345,44096,910-582-1746
121,Barbara M Aaron,705 Old Barn Ave,Durham,NC,27704,44117,919-598-5714
122,Joey M. Rochford,"23-B 2800 Woodlawn Dr,",Ballwin,MO,63011,3999707,721-144-7436
123,Bob Rubenstein,3939 Ruffin Rd.,St. Louis,Mo.,63021,40851,297-073-4204
124,Bland Aaron,125 Pear Tree Rd,Troutman,NC,28166,44179,
125,Brian Aaron,612 Hampton,Eden,NC,27288,44200,336-627-5734
126,C E Aaron,106 Apache Trl,Wilmington,NC,28409,44221,910-251-1487
127,C Lynn Aaron,2359 Cambridge,West End,NC,27376,44242,910-673-1181
128,Cenitra Aaron,702 Miller Ave,Fayetteville,NC,28304,44262,910-488-5747
129,Charles Aaron,325 Mcgalliard Park Ave NE,Valdese,NC,28690,-999999,828-874-2924
130,Cindy Aaron,5400 Pulley Town Rd,Zebulon,NC,27597,44304,919-404-1963
131,Cliff Aaron,500 Umstead Dr,Chapel Hill,NC,27516,44325,919-942-1239
132,D P Aaron,2475 Spicewood Dr,Winston Salem,NC,27106,44346,336-703-1146
133,D R Aaron,2644 Tantelon Pl,Winston Salem,NC,27127,44366,336-703-1145
134,Lou Voss,777 Harbor Blvd S,Bellvue,WA,98006,41,357-989-4735
135,David Aaron,2521 Westmoreland Dr,Greensboro,NC,27408,44408,336-286-5748
136,Dewey Aaron,336 Billie Harris St,Eden,NC,27288,44429,336-627-5735
137,Donald & Celia Aaron,202 Country Club Blvd.,Jacksonville,NC,28540,44450,910-347-4721
138,Donald Aaron,202 Country Club Blvd,Jacksonville,NC,28540,44470,910-347-4726
139,Frances Mrs Aaron,1145 Conley St,Winston-Salem,NC,27105,44491,336-703-1171
140,Frank J Aaron,160 Sunny Ridge Rd,Hendersonville,NC,28739,44512,828-685-8695
141,Geary Dixxon,106 Fidelity St.,Charlotte,n.c.,28208,44533,704-596-5720
142,Gary Dixon,106 Fidelity St,Charlotte,NC,28208,44554,704-596-5719
143,Gary Dickson,106 Fidelity Street,Charlotte,NC,28208,44574,704-596-5718
144,Cindy Aron,5400 Pully Town Rd.,Zebulon,N.C.,27597,44595,919-404-1109
145,"Rain Bird Corp. Svc., Inc.",832 Brooke Rd.,Va Beach,VA,23454,39645,549-354-2416
146,Greg Aaron,1833 S Hawthorne Rd,Winston-Salem,NC,27103,44637,336-703-8437
147,Cathy Lapp,955 Deer Run,Centerville,OH,45409,40082,718-922-0353
148,Mr. Joe Rochford,"Apartment 23-B 2800 Woodlawn Dr,",Ballwin,MO,63011,3999707,721-144-7436
149,Hoyt S Aaron,711 S Lexington Ave,Burlington,NC,27215,44699,336-261-9834
150,J N Aaron,2644 Tantelon Place,Winston Salem,NC,27127,44720,336-703-1167
151,Jake Aaron,1895 Lindsey Bridge Rd,Madison,NC,27025,44741,336-548-8527
152,James Aaron,204 Brookford Ct,Fayetteville,NC,28314,44762,910-488-5746
153,James E Aaron,408 Irma Ave,Lexington,NC,27292,44782,336-243-6987
154,James P Aaron,2607 Cashwell Dr,Goldsboro,NC,27534,44803,919-735-5734
155,Jan Aaron,428 Chester Woods Ct,HighPoint,NC,27262,44824,336-869-7725
156,Jeff Aaron,428 Chester Woods Ct,HighPoint,NC,27262,44845,336-841-6375
157,Jeff Aaron,101 Greenwood Avenue,Rocky Mt,NC,27804,44866,252-446-3974
158,Jerry Aaron,3859 Wilkersham Way,Fayetteville,NC,28306,44886,910-488-5748
159,Jethro Mrs Aaron,1310 Mulberry Ave,Charlotte,NC,28216,44907,704-596-5717
160,Rain Bird Corporate Services.,832 Brooke Rd #100,Virginia Beach,Virginia,23454,39645,549-354-2416
161,John Aaron,817 Stuart St,Eden,NC,27288,44949,336-627-5737
162,John Aaron,2 Yester Oaks Ct,Greensboro,NC,27455,44970,336-286-5773
163,John W Aaron,7631 Pine St,Rural Hall,NC,27045,44990,336-969-9385
164,K Michael Aaron,1160 Twelve Tree Rd.,Asheboro,NC,27203,45011,336-879-9434
165,Lisa Aaron,7604 Clearwater Ct.,Raleigh,NC,27603,45032,919-870-9965
166,Lloyd D Aaron,1359 Pinebluff Rd,Winston Salem,NC,27103,45053,336-703-1158
167,M Aaron,720 Jonestown Rd,Winston Salem,NC,27103,45074,336-703-1165
168,M C Aaron,3031 Pisgah Pl,Greensboro,NC,27455,45094,336-286-5744
169,M D Aaron,105 Westdale Ave,Lexington,NC,27292,45115,336-243-1072
170,Malcolm Aaron,204 Roberson St,Carrboro,NC,27510,45136,919-967-4815
171,Margaret W Aaron,103 S Cleveland Ave,Winston Salem,NC,27101,45157,336-703-1163
172,Mark & Cristi Aaron,3657 Foster Rd,Yanceyville,NC,27379,45178,336-694-7559
173,Michael Aaron,224 Barnes Rd.,Eden,NC,27288,45198,336-627-5739
174,Michael Aaron,865 N Saylor Street,Southern Pines,NC,28387,45219,910-692-5755
175,Minnie Aaron,515 Briarwood Dr,Charlotte,NC,28215,45240,704-596-5716
176,"%Fidelity Federal Bank, Inc.",PO #429,Woodfields,OH,43793,39749,306-312-4292
177,N L Aaron,116 Fairway Knoll,Blowing Rock,NC,28604,45282,828-355-5066
178,Neal Aaron,7687 Proud Street,Pfafftown,NC,27040,45302,336-945-9874
179,Neal C & Barbara Aaron,7442 Saint Clair Dr,Charlotte,NC,28270,45323,704-596-5702
180,Nita L Aaron,210 Willow Hound Ears,Blowing Rock,NC,28604,45344,828-355-4427
181,P Aaron,5032 Hunt Club Rd,Wilmington,NC,28403,45365,910-251-1474
182,P H Aaron,211 W 4th St,Conover,NC,28613,45386,828-465-1478
183,P H Aaron,2644 Tantelon Pl,Winston Salem,NC,27127,45406,336-703-1159
184,Patti Aaron,4719 New Hope Rd,Raleigh,NC,27604,45427,919-870-9964
185,Paul Aaron,6916 Union Grove Church Rd,Hillsborough,,27278,45448,919-732-7784
186,Paul Aaron,107 Corral Way,Jacksonville,NC,28546,45469,910-347-4727
187,Paul Aaron,1913 Park Ave,Rockingham,NC,28379,45490,910-895-8110
188,Paul Dr Dc Aaron,103 E King St,Hillsborough,NC,27278,45510,919-732-7655
189,Randy & Sherri Aaron,102 Treetop Court,Trinity,NC,27370,45531,336-431-1498
190,Randy & Sherri Fax Line Aaron,102 Treetop Crt.,Trinity,NC,27370,45552,336-431-1415
191,Reginald Aaron,333 Pervie Bolick St,Eden,NC,27288,45573,336-627-5740
192,Richard Aaron,404 Jefferson Dr,Fayetteville,,28304,45594,910-488-5752
193,Roger D Aaron,2013 Williamsburg Manor Ct,Winston Salem,NC,27103,45614,336-703-1160
194,Roland Aaron,529 Ross Grove Rd. E,Shelby,NC,28150,45635,704-484-7491
195,Ronald Aaron,740 Efird St,Albemarle,NC,28001,45656,704-322-4007
196,Ronald Aaron,36805 Old Colony Ln,Albemarle,,28001,45677,704-935-4011
197,S Edward Aaron,33 Ocala St,Arden,NC,28704,45698,828-633-9274
198,Sam Aaron,7691 Nc Highway,Madison,NC,27025,45718,336-548-2715
199,Sarah Aaron,12384 Buck Rd,Middlesex,NC,27557,45739,919-284-1593
200,Stephen & Christopher Aaron,3859 Wilkersham Way,Fayetteville,NC,28306,47840,910-488-5735
201,Steve Aaron,1740 10th Street Ct NW,Hickory,NC,28601,47861,828-328-2444
202,Steven L Aaron,204 Long Branch Ln,Burgaw,NC,28425,47882,910-259-1234
203,Taylor Aaron,15 Alpen Rose Way,Horse Shoe,NC,28742,47902,828-890-2880
204,Tim & Jane Aaron,305 Stadium Dr,Wake Forest,NC,27587,47923,919-569-3519
205,Tony Aaron,226 Cleve St,Fayetteville,NC,28303,47944,910-488-5750
206,V O Aaron,4951 Hunt Club Rd,Winston Salem,NC,27104,47965,336-703-1162
207,W Aaron,705 Old Barn Ave,Durham,NC,27704,47986,919-598-5706
208,W L Aaron,615 Summit dr,Lexington,NC,27292,48006,336-243-1074
209,William Aaron,232 Wendover Ln,Wilmington,NC,28405,48027,910-251-1467
210,Jason R Aarons,2316 Ginger Ln,Charlotte,NC,28213,48048,704-596-5714
211,Mark G MD Res Aarons,223 Pine Grove Rd,Southern Pines,NC,28387,48069,910-692-5852
212,Mark MD Aarons,223 Pine Grove Rd,Southern Pines,NC,28387,4090,910-692-3697
213,William R Aarons,22 Shelby Dr,Asheville,NC,28803,48110,828-633-4075
214,David R Rev Aaronson,9621 Marbrook Dr,Charlotte,NC,28226,48131,704-596-5726
215,Matt Aaronson,3910 Blakeford Dr,Durham,NC,27713,488152,919-598-5710
216,Pieter Aarsbergen,51 Williams Cir,Chapel Hill,NC,27516,48173,919-942-1237
217,Randy L Aarsund,4402 N Sharon Amity Rd,Charlotte,NC,28205,48194,704-596-5712
218,Nancy Aarts,100 Rock Haven Rd,Carrboro,NC,27510,48214,919-967-8527
219,Melvin Aaseby,2680 Hopewell Friends Rd,Asheboro,NC,27203,48235,336-879-8148
220,Kari Aasen,245 Wyndham Cir,Greenville,n.c.,27858,48256,252-752-6986
221,J W Aashe,217 Russellville Ct,Fayetteville,NC,28306,48277,910-488-5738
222,Ronald & Nanc Aasland,106 Timber View Ln,Cary,NC,27511,48298,919-460-5185
223,Lauren C Aaslestad,507 W Main St,Mt Olive,NC,28365,48318,919-658-5222
224,Barbara Aasness,7327 Lancashire Dr,Charlotte,NC,28227,48339,704-596-5711
225,Wayne I Aavang,1309 Freedom Mill Rd,Gastonia,NC,28052,48360,704-827-8623
226,Arnold Aavaste,3921 Miriam Dr,Charlotte,NC,28205,48381,704-596-5710
227,Lia Aavaste,3921 Miriam Dr,Charlotte,NC,28205,48402,704-596-5709
228,Sven Aavaste,313 Green Oak Dr,Belmont,NC,28012,48422,704-461-4047
229,Dean Ab-Hugh,6306 E Yacht Dr,Oak Island,NC,28465,48443,910-278-6349
230,Christian Abad,521 Meadowview Dr,Boone,NC,28607,48464,828-355-6785
231,Jorge Abad,710 Godwin Ct,Raleigh,NC,27606,48485,919-870-9956
232,Luis Abad,100 Somersby Ct,Cary,NC,27513,48506,919-531-7329
233,Douye Abadi,4629 Perth Ct,Charlotte,NC,28215,48526,704-596-5708
234,Ghazanfar Abadi,3800 Dewitt Ln,Charlotte,NC,28217,48547,704-596-5707
235,Edgard Abadia,171 Goldfinch Ln,New Bern,NC,28560,48568,252-638-2775
236,Teos Abadia,13 Tarawa Ter,Durham,NC,27705,48589,919-598-5735
237,Greg & Vicki Abadie,11 Mill Creek Ct,Greensboro,NC,27407,48610,336-286-5762
238,John Abadie,3815 Obriant Pl,Greensboro,NC,27410,48630,336-286-5763
239,Matthew J Abadie,712 Aiport Rd,Chapel Hill,NC,27514,48651,919-942-1238
240,Myra L Abadie,145 E Holt St,Burlington,NC,27217,48672,336-221-1772
241,Vicki & Greg Abadie,11 Mill Creek Ct,Greensboro,NC,27407,48693,336-286-5739
242,Carmelita Abadilla,328 Foxfield Ln,Matthews,NC,28105,48714,704-844-2617
243,Edgardo Abagat,413 Kirkcaldy Ct,Fayetteville,NC,28314,48734,910-488-5734
244,Aj Abahazi,1510 Turfwood Dr,Pfafftown,NC,27040,48755,336-945-3274
245,Nena Abai-Ikwechegh,101 Flintwood Ct,Winston Salem,NC,27106,48776,336-703-1169
246,B Abalos,3312 Winston Blvd,Wilmington,NC,28403,48797,910-251-1469
247,E Abalos,7854 Adrian Dr,Fayetteville,NC,28314,48818,910-488-5737
248,Lorenzo B Abalos,317 Brentwood Ave,Jacksonville,NC,28540,48838,910-347-4867
249,Martin Abalos,175 Brocton Dr,Fayetteville,NC,28303,48859,910-488-5742
250,Socorro Abame,800 E Franklin St,Monroe,NC,28112,48880,704-296-5863
251,Daniel Abanathey,5317 Tern Pl,Fayetteville,NC,28311,48901,910-488-5739
252,Estelito D Abar,1120 Camden Rd,Fayetteville,NC,28306,48922,910-488-5741
253,Nari Abar,5900 Ebenezer Church Rd,Raleigh,NC,27612,48942,919-870-9979
254,M Abarbanell,23 Hunting Country Trl,Tryon,NC,28782,48963,828-859-5279
255,Abel B Abarca,6509 Wisteria Dr,Charlotte,NC,28210,48984,704-596-5706
256,Alfonso Abarca,6507 Wisteria Dr,Charlotte,NC,28210,49005,704-596-5705
257,E Abarca,9911 Edwards Pl,Mint Hill,NC,28227,49026,704-545-6674
258,Eloy Abarca,2948 Ligon St,Raleigh,NC,27607,49046,919-740-1505
259,Rodofo Antonio Abarca,6110 San Rey Ct,Charlotte,NC,28215,49067,704-596-5704
260,Roman Abarca,2387 Ryan Dr,Randleman,NC,27317,49088,336-498-7567
261,Clifton Abare,900 Falls Creek Ln,Charlotte,NC,28209,49109,704-393-5694
262,Mark Abare,105 Rosedown Dr,Cary,NC,27513,49130,919-740-8333
263,David Abashian,109 Whisper Creek Ct,Cary,NC,27513,49150,919-531-4484
264,Greg Abashian,2908 Green Hill Dr,Durham,NC,27705,49171,919-598-5733
265,R Abashian,3129 Coachmans Way,Durham,NC,27705,49192,919-598-5732
266,Steven Abashian,2200 Emerson Rd,Kinston,NC,28501,49213,252-527-0311
267,T Abashian,1500 Tyler Ct,Durham,NC,27701,49234,919-598-5731
268,Aniedi Abasiekong,609 E Marion St,Shelby,NC,28150,49254,704-484-6046
269,Mohga Abaskhroun,601 Sills Dr,Knightdale,NC,27545,49275,919-266-1679
270,Anthony Abate,312 W Park St,Cary,NC,27511,49296,919-272-8288
271,Frank M Abate,4312 Myers Park Dr,Durham,NC,27705,49317,919-598-5720
272,Joesph D Abate,3815 Antelope Trl,Wilmington,NC,28409,49338,910-251-1476
273,Joseph Abate,1636 Quail Ridge Rd,Raleigh,NC,27609,49358,919-740-1490
274,Joseph D Abate,104 Haringey Dr,Raleigh,NC,27615,49379,919-740-1497
275,Mark Abate,8004 Halifax Rd,Youngsville,NC,27596,49400,919-556-0159
276,Steven Abate,200 Coatbridge Cir,Cary,NC,27511,49421,919-460-9923
277,Suzanne Abate,903 Foxborough Rd,Charlotte,NC,28213,49442,704-596-5713
278,Theresa Abate,5410 Fredrick St,Indian Trail,NC,28079,49462,704-821-7489
279,Rocco Abatemarco,16 Kippen Ct,Pinehurst,NC,28374,49483,910-295-1987
280,Maurice H Abay-Abay,5213 Morrozoff Dr,Fayetteville,NC,28306,49504,910-488-5751
281,Deyu Abayhan,531 Marshall Way,Durham,NC,27705,49525,919-598-5727
282,Ibrahim Abayhan,1900 Kirkwood Dr,Durham,NC,27705,49546,919-598-5705
283,Russ & Canan Abayhan,1025 Inverness Rd,Southern Pines,NC,28387,49566,910-692-1235
284,Samuel Abayhan,225 N Mineral Springs Rd,Durham,NC,27703,49587,919-598-5722
285,Mohamed Abaza,180 Bpw Club Rd,Carrboro,NC,27510,49608,919-967-3697
286,Kingsley Abaze,222 Glen Bridge Rd,Arden,NC,28704,49629,828-633-4036
287,Abo-Obidah Abazid,209 Ramblewood Dr,Raleigh,NC,27609,49650,919-740-1493
288,Ayman Abazid,216 Farrington Dr,Raleigh,NC,27615,49670,919-740-1499
289,John Luke Abaziou,8200 S Crestwick Ct,Raleigh,NC,27615,49691,919-740-1503
290,Mike & Vicky Abba,1423 Moorescrest Pl,Kannapolis,NC,28081,49712,704-933-5470
291,Joseph P Abban,7113 Kearny Ave,Fayetteville,NC,28314,49733,910-488-5733
292,Ammar Abbas,412 Paladin Dr,Greenville,NC,27834,49754,252-752-6985
293,Haider Dr Abbas,2001 Sunny Way,Clayton,NC,27520,49774,919-553-6814
294,Leon E Abbas,114 Woodland Dr,Cary,NC,27513,49795,919-272-2263
295,Mohamed Abbas,2206 Honeycutt Simpson Rd,Monroe,NC,28110,49816,704-296-5005
296,Reza Abbas,1704 Calvery View Ln,Clemmons,NC,27012,49837,336-766-5691
297,Stephen Abbas,9626 Vinca Cir,Charlotte,NC,28213,49858,704-596-5715
298,Nesir Jamel Abbasi,365 Montrose Dr,Greensboro,NC,27407,49878,336-286-5758
299,Valeh Abbasi,7012 Snow Ln,Charlotte,NC,28227,49899,704-393-5706
300,Fred F Abbaspour,108 Seasons Dr,Raleigh,NC,27614,52000,919-740-1495
301,Jan Abbassi,114 E Peachtree Dr,High Point,NC,27265,52021,336-869-4407
302,M Abbat,915 Collins Dr,Raleigh,NC,27609,52042,919-740-1494
303,Pierre Abbat,119 S College St,Metter,NC,30439,52062,704-541-2565
304,Anthony Abbata,9915 Patrick Springs Ct,Charlotte,NC,28200,52083,704-393-5705
305,Angelo Abbate,209 W Markham Ave,Durham,NC,27701,52104,919-598-5724
306,Guy Abbate,116 Balsam Dr,Waynesville,NC,28786,52125,828-456-5851
307,Jennifer Abbate,2305 Shade Valley Rd,Charlotte,NC,28205,52146,704-393-5704
308,Joe Abbate,1512 Quail Ridge Rd,Raleigh,NC,27609,52166,919-870-9974
309,Michael F Abbate,3307 Hard Rock Ct,Indian Trail,NC,28079,52187,704-821-3488
310,Olivia P Abbate,4504 Greenbriar Rd,Raleigh,NC,27603,52208,919-740-1491
311,Richard V Abbate,9201 Doe Ct,Charlotte,NC,28277,52229,704-393-5703
312,Robert & Sue Abbate,2210 S Gardner St,Gastonia,NC,28054,52250,704-827-7265
313,Tony Abbate,6210 Litchford Rd,Raleigh,NC,27615,52270,919-740-1502
314,William V Abbate,107 Mcwaine Ln,Cary,NC,27513,52291,919-467-9372
315,Joseph Abbatiello,7036 Reedy Creek Rd,Charlotte,NC,28215,52312,704-393-5702
316,R V Jr Abbatt,9201 Doe Ct,Charlotte,NC,28277,52333,704-393-5701
317,Fathy Abbdelalim,5242 Vann St,Raleigh,NC,27606,52354,919-740-1500
318,Carl Abbe,6304 Lakebend Ct,Greensboro,NC,27410,52374,336-286-5766
319,D Abbe,2907 Beckworth Ct,High Point,NC,27260,52395,336-886-5213
320,David J Abbe,5413 Wheatcross Pl,Raleigh,NC,27610,52416,919-740-1492
321,Don & Glenda Abbe,1002 Manchester Dr,Cary,NC,27511,52437,919-272-4729
322,Kenneth W Abbe,1700 5th Ave W,Hendersonville,NC,28739,52458,828-685-8693
323,M L Abbe,1617 Beechgrove Rd,Raleigh,NC,27612,52478,919-740-1508
324,Paul Rev & Ma Abbe,1617 Beechgrove Rd,Raleigh,NC,27612,52499,919-740-1501
325,I Abbenante,113 Basswood Ct,Chapel Hill,NC,27514,52520,919-942-1245
326,Marie Abbene,104 Ethans Glen Ct,Cary,NC,27513,52541,919-531-9402
327,Brent D & Demetra Abbey,213 S Gurney St,Burlington,NC,27215,52562,336-221-3287
328,Charles W Abbey,3626 Tanglebrook Trl,Clemmons,NC,27012,52582,336-766-5690
329,Christopher Abbey,229 E King St,Boone,NC,28607,52603,828-355-9234
330,David Abbey,501 Shepard Sq,Brevard,NC,28712,52624,828-884-4297
331,Donald D Abbey,7110 Graburn Rd,Charlotte,NC,28226,52645,704-393-5700
332,Edward Abbey,113 Hedgestone Dr,Gastonia,NC,28056,52666,704-827-8204
333,Edward Abbey,298 Lake Herron Dr,Olivia,NC,28368,52686,
334,G Abbey,2205 Yager Creek Dr,Charlotte,NC,28273,52707,704-393-5699
335,Joseph Abbey,1982 Countrywood Blvd,Jacksonville,NC,28540,52728,910-347-4723
337,Kirk Abbey,2104 Mariner Cir,Raleigh,NC,27603,52770,919-740-1897
338,Lillian Abbey,600 Canal Dr,Dunn,NC,28334,52790,910-892-7379
339,M W Abbey,112 Locust Tr,Ellenboro,NC,28040,52811,828-453-7337
340,M W Abbey,202 Briarwood Ln,Forest City,NC,28043,52832,828-245-8573
341,Martin Abbey,1750 20th Avenue Dr NE,Hickory,NC,28601,52853,828-328-2445
342,Mike Abbey,5950 Mcnair Rd,Charlotte,NC,28212,52874,704-393-5698
343,R Craig Abbey,211 Shoals Ln,Garner,NC,27529,52894,919-662-7489
344,Rachel Abbey,1000 Smith Level Rd,Carrboro,NC,27510,52915,919-967-7486
345,Robert H Abbey,5856 Old Oak Ridge Rd,Greensboro,NC,27410,52936,336-286-5756
346,Robert W Abbey,2925 Nc Highway 42 S,Asheboro,NC,27203,52957,336-879-8189
347,Ronald & Patricia Abbey,906 Crystalwood Ct,Concord,NC,28027,52978,704-786-5689
348,S L Abbey,13303 Harbor Oaks Dr,Charlotte,NC,28278,52998,704-596-5700
349,Scott C Abbey,202 Briarwood Ln,Forest City,NC,28043,53019,828-245-1252
350,Shelia M Abbey,4807 Bancroft Dr,Durham,NC,27705,53040,919-598-5691
351,Sim A III Ins Abbey,1409 East Blvd,Charlotte,NC,28203,53061,704-393-5697
352,Sim A III Ins Res Abbey,5019 Beckford Dr,Charlotte,NC,28226,53082,704-596-5703
353,Steve & Sandie Abbey,327 Old Calvary Church Rd,Mooresboro,NC,28114,53102,828-657-6710
354,T Abbey,5900 Timber Creek Ln,Raleigh,NC,27612,53123,919-870-9989
355,Wilbur & Dorothy Abbey,1029 Quakenbush Rd,Snow Camp,NC,27349,53144,336-228-1082
356,Michael Abbington,21 W 5th Ave,Lexington,NC,27292,53165,336-243-1075
357,B Abbit,4314 Commonwealth Ave,Charlotte,NC,28205,53186,704-393-5695
358,C H Abbitt,305 E Albatross St,Kill Devil Hills,NC,27948,53206,252-441-2784
359,C R Abbitt,312 W Morehead St,Reidsville,NC,27320,53227,336-349-9687
360,Chester & Linda Abbitt,5522 Bunch Rd,Summerfield,NC,27358,53248,336-643-2122
361,Collin M Jr Abbitt,1898 Nc Highway 68 N,Oak Ridge,NC,27310,53269,336-644-0554
362,Dan & Kimberly Abbitt,722 E Donaldson Ave,Raeford,NC,28376,53290,910-875-6384
363,H W Abbitt,314 E Boardwalk,Atlantic Beach,NC,28512,53310,252-523-9574
364,H W Jr Abbitt,39 Fountain Manor Dr,Greensboro,NC,27405,53331,336-286-5742
365,R B Abbitt,113 River Rd N,Roanoke Rapids,NC,27870,53352,252-533-0961
366,Russell D Abbitt,1133 Branch St NW,Wilson,NC,27893,53373,252-291-4317
367,Sindy L Abbitt,715 Hall St,Salisbury,NC,28144,53394,704-636-3671
368,Willard Mrs Abbitt,304 Charlotte Ave,Carolina Beach,NC,28428,53414,910-458-3675
369,Willard Mrs Abbitt,106 Peachtree St,Roxboro,NC,27573,53435,336-599-1979
370,Rajesh Abbl,118 Ripley Ct # Cary,Cary,NC,27513,53456,919-531-5633
371,L J Abbood,540 Marshburn Rd,Wendell,NC,27591,53477,919-365-8440
372,Allan Abbot,1851 Highway 150 E,Denver,NC,28037,53498,704-820-0332
373,Kay Abbot,3 Kings Mount Ct,Durham,NC,27713,53518,919-598-5699
374,Mark Abbot,134 Victor Dr,Boiling Springs,NC,28017,53539,828-355-4015
375,R N Abbot,755 Critcher Rd,Boone,NC,28607,53560,828-355-1132
376,A Beth Abbott,8 Woodstream Ln,Greensboro,NC,27410,53581,336-286-5746
377,A M Abbott,8321 Nc Highway,Ruffin,NC,27326,53602,336-939-7090
378,Agnes Abbott,807 Southerland St,Henderson,NC,27536,53622,252-492-5917
379,Albert A Abbott,550 Murphy Rd,Henderson,NC,27536,53643,252-492-5919
380,Albert L Abbott,4773 Woodlark Ln,Charlotte,NC,28211,53664,704-393-5707
381,Alice Abbott,812 Shepard St,Morehead City,NC,28557,53685,252-808-2741
382,Andrew Abbott,224 Brightwood Rd,Wilmington,NC,28409,53706,910-251-1473
383,Andrew G Jr Abbott,712 Cardinal Dr,Henderson,NC,27536,53726,252-492-5920
384,Andy & Wanda Abbott,8101 Ragan Rd,Apex,NC,27502,53747,919-362-9348
385,Angeline M Abbott,1700 Maplewood Ln,Greensboro,NC,27407,53768,336-286-5734
386,Ann Abbott,120 Allen Branch Rd,Sylva,NC,28779,53789,828-586-7839
387,Anthony Abbott,571 Coral Ridge Rd,Pine Knoll Shores,NC,28512,53810,
388,Anthony S Abbott,313 Woodland St,Davidson,NC,28036,53830,704-895-4240
389,Arthur M Abbott,9602 Deer Spring Ln,Charlotte,NC,28210,53851,704-393-5693
390,Aubrey Abbott,2701 Homestead Rd,Chapel Hill,NC,27516,53872,919-942-1242
391,B Abbott,17 Upland Rd,Asheville,NC,28804,53893,828-633-4192
392,B J Abbott,5916 Westcreek Pl,Raleigh,NC,27606,53914,919-870-9993
393,B N Abbott,109 N Capps St,Pine Level,NC,27568,53934,919-965-5591
394,Benjamin P Abbott,221 Riggs Rd,Hubert,NC,28539,53955,910-326-5677
395,Beth Abbott,5808 Pointer Dr,Raleigh,NC,27609,53976,919-870-9982
396,Betty Abbott,4082 Grace Chapel Rd,Granite Falls,NC,28630,53997,828-396-7781
397,Beverly Abbott,3901 Old US Hwy,Providence,NC,27315,54018,
398,Bill Abbott,6706 Bevington Brook Ln,Charlotte,NC,28277,54038,704-393-5692
399,Bill Abbott,105 W Washington St,Mayodan,NC,27027,54059,336-427-0885
400,Bill & Linda Abbott,105 W Washington St,Mayodan,NC,27027,56160,336-427-0243
401,Bob & Ginnie Abbott,1406 Red Banks Rd,Greenville,NC,27858,56181,252-752-6987
402,Bobo Abbott,5307 Camellia Ln,Lumberton,NC,28358,56202,910-738-1678
403,Brien & Tamie Abbott,1928 Summey Ave,Charlotte,NC,28205,56222,704-393-5691
404,Bruce Abbott,611 N 3rd St,Mebane,NC,27302,56243,919-563-6963
405,Bruce C Abbott,7508 Oak Valley Ln,Browns Summit,NC,27214,56264,336-375-3574
406,Buster Abbott,157 Thorpe St,Henderson,NC,27536,56285,252-492-5922
407,C E Abbott,1400 Gay St,Rocky Mt,NC,27804,56306,252-443-6374
408,C L Abbott,451 Boxwood Ln,Brevard,NC,28712,56326,828-884-1467
409,C L Abbott,8429 Longfield Dr,Raleigh,NC,27604,56347,919-870-9980
410,C R Abbott,441 Kaywoody Ct,Raleigh,NC,27615,56368,919-740-1487
411,Carl J & Brenda O Abbott,828 Mahala Rd,Creston,NC,28615,56389,252-453-9687
412,Carrie L Abbott,2106 Emerson Rd,Kinston,NC,28501,56410,252-527-0312
413,Charles Abbott,1909 Merion Pl,Raleigh,NC,27615,56430,919-870-9978
414,Charles Abbott,3401 Old Vineyard Rd,Winston Salem,NC,27103,56451,336-703-1150
415,Charles C Abbott,421 Myrtle Pond Rd,Corolla,NC,27927,56,252-453-7845
416,Charles Dale Jr Abbott,6329 Battleview Dr,Raleigh,NC,27613,56493,919-870-9977
417,Charles W Abbott,110 Robinhood Dr,Jacksonville,NC,28546,56514,910-347-4728
418,Chester Abbott,505 W Walnut St,Selma,NC,27576,56534,919-965-7538
419,Christina Abbott,1701 River Dr,Greenville,NC,27858,56555,252-752-6990
420,Christopher Abbott,270 W King St,Boone,NC,28607,56576,828-355-8532
421,Christopher Abbott,600 Audubon Lake Dr,Durham,NC,27713,56597,919-598-5689
422,Clarence B Abbott,205 Thompson Heights Rd,Reidsville,NC,27320,56618,336-349-9457
423,Clarence L Abbott,1607 Howard Av Ext,Tarboro,NC,27886,56638,252-823-3831
424,Constance Abbott,7039 Brandemere Ln,Winston Salem,NC,27106,56659,336-703-1148
425,Cora Foster Abbott,5501 Davis Mill Rd,Greensboro,NC,27406,56680,336-286-5737
426,Cornelia Abbott,5856 Nc Highway,Eden,NC,27288,56701,336-627-5738
427,Cue P Abbott,3512 Doc Bennett Rd,Fayetteville,NC,28306,56722,910-488-5745
428,Curtis Jr Abbott,1302 Valley Rd,Garner,NC,27529,56742,919-7798432
429,Cynthia L Abbott,5357 E Nc Highway,Browns Summit,NC,27214,56763,336-375-4567
430,D Abbott,1101 Timber Trl,Asheville,NC,28804,56784,828-239-3096
431,D Abbott,11 Covey Ln,Greensboro,NC,27406,56805,336-286-5745
432,D C Jr Abbott,6630 Gaywind Dr,Charlotte,NC,28226,56826,704-393-5690
433,D L Abbott,4779 Old Walker Mill Road Ext,Randleman,NC,27317,56846,336-498-8761
434,D N Abbott,2615 Lake Wheeler Rd,Raleigh,NC,27603,56867,919-870-9976
435,Dale Abbott,6329 Battleview Dr,Raleigh,NC,27613,56888,919-740-1477
436,David Abbott,3101 Girard Ct,Charlotte,NC,28212,56909,704-393-5689
437,David B Abbott,903 Lexington Ave,Charlotte,NC,28203,56930,704-596-5732
438,David B Abbott,173 Dorsey Pl,Henderson,NC,27536,56950,252-492-5912
439,David H Abbott,2161 N Salem St,Apex,NC,27502,56971,919-362-8657
440,David W Abbott,6258 Hawks Bill Dr,Wilmington,NC,28409,56992,910-251-1485
441,Debbie & Curtis Abbott,301 Railroad St,Rockwell,NC,28138,57013,704-279-7580
442,Deen & Holly Abbott,125 Highland Ct,Jacksonville,NC,28540,57034,910-347-4725
443,Dena Abbott,1471 Airport Rd,Chapel Hill,NC,27514,57054,919-942-1241
444,Denise L Abbott,6309 Hunt Rd,Pleasant Garden,NC,27313,57075,336-674-5511
445,Dennis C Abbott,4126 Aycock Ln,Charlotte,NC,28209,57096,704-596-5731
446,Dennis E Abbott,205 Crest Rd,Henderson,NC,27536,57117,252-492-6712
447,Donald H Abbott,3921 US Highway 64 W,Apex,NC,27502,57138,919-362-5713
448,Donald H Abbott,104 Charolais Trl,Cary,N Carolina,27513,57158,919-531-0063
449,Donna Abbott,115 W Jennette Ave,Henderson,NC,27536,57179,252-492-5924
450,Donna & Durwa Abbott,1105 Windward Passage,Knightdale,NC,27545,57200,919-266-3498
451,Douglas J Abbott,464 Heritage Dr,Lewisville,NC,27023,57221,336-945-5059
452,Doyal Abbott,501 Applecross Dr,Cary,NC,27511,57242,919-272-4432
453,Dwayne Abbott,2839 Ladale Ln,Mebane,NC,27302,57262,919-563-7842
454,E Abbott,214 S Park Dr,Greensboro,NC,27401,57283,336-286-5733
455,E E Rev Abbott,765 Goose Pond Rd,Ruffin,NC,27326,57304,336-939-8913
456,E G Abbott,849 Noell Ln,Rocky Mt,NC,27804,57325,252-446-3356
457,Edward A Abbott,138 Tyvola Dr,Charlotte,NC,28210,57346,704-596-5730
458,Edward C Abbott,704 W D St,Butner,NC,27509,57366,919-575-4862
459,Elizabeth Abbott,5 Coriander Ct,Flat Rock,NC,28731,57387,828-698-9207
460,Eric W Abbott,3116 Heathstead Pl,Charlotte,NC,28210,57408,704-596-5729
461,Ernest Abbott,2201 E Lake Shore Dr,Wilmington,NC,28401,57429,910-251-1465
462,F E Abbott,915 Lynn Dr,Kinston,NC,28501,57450,252-527-0315
463,F Lynn Abbott,4260 Brownsboro Rd,Winston Salem,NC,27106,57470,336-703-1144
464,Fran Abbott,198 Kimberly Ave,Asheville,NC,28804,57491,828-225-9607
465,Frank J Jr Abbott,119 Northridge Tr,Olivia,NC,28368,57512,
466,Frank J Jr Abbott,105 W 11th St,Southport,NC,28461,57533,910-457-5150
467,Frank R Abbott,4914 Shelley Dr,Wilmington,NC,28405,57554,910-251-1477
468,Frederick Abbott,201 S Clark St,Nashville,NC,27856,57574,252-459-2532
469,Fredrick J Abbott,209 Oaklane Ave,Randleman,NC,27317,57595,336-498-2644
470,G Abbott,614 Tucker St,Burlington,NC,27215,57616,336-792-5623
471,G Keith Jr Abbott,3413 Brookview Dr,Rocky Mt,NC,27804,57637,252-446-8974
472,Gary Abbott,677 Roanoke Ave,Henderson,NC,27536,57658,252-492-5929
473,Gary & Scott Abbott,5409 Marina Club Dr,Wilmington,NC,28409,57678,910-251-1478
474,Gene D Jr Abbott,7476 Friendship Ledford Rd,Winston Salem,NC,27107,57699,336-703-1147
475,George Abbott,8712 W Lake Ct,Raleigh,NC,27613,57720,919-740-1486
476,George R Abbott,80 Wesley St,Canton,NC,28716,57741,828-648-3697
477,Glenn Abbott,3725 Watkins St,Walkertown,NC,27051,57762,336-595-8299
478,Greg A Abbott,105 Fox Briar Ln,Cary,NC,27511,57782,919-272-8390
479,H D Abbott,196 Lilly Rd,South Mills,NC,27976,57803,252-335-4036
480,H L Abbott,2288 18th Ave NE,Hickory,NC,28601,57824,828-328-2443
481,Hal Abbott,1211 Perdido Ct,Garner,NC,27529,57845,919-772-7977
482,Hal Abbott,1211 Perdido Ct Garnr,Raleigh,NC,27600,57866,919-740-1485
483,Harold V Abbott,306 Seminole Trl,Jacksonville,NC,28540,57886,910-347-4724
484,Harriet C Abbott,4616 Lawndale Dr,Greensboro,NC,27455,57907,336-286-5779
485,Harriett Abbott,445 Clark Rd,Salisbury,NC,28146,57928,704-636-3687
486,Harry Abbott,1014 Church St,Eden,NC,27288,57949,336-627-5733
487,Harry T & Bernice Abbott,104 Pinnacle Ridge Rd,Banner Elk,NC,28604,57970,828-898-1114
488,Horace Abbott,524 Godwin Ave,Lumberton,NC,28358,57990,910-739-6571
489,Howard D Abbott,145 Farmingdale Ave,Winston Salem,NC,27107,58011,336-703-1157
490,Hubert C Abbott,605 Woodland Rd,Raleigh,NC,27603,58032,919-740-1484
491,I M Abbott,925 E Sprague St,Winston Salem,NC,27107,58053,336-703-1149
492,J Abbott,7600 Peggy Dr,Clemmons,NC,27012,58074,336-766-5691
493,J Abbott,3009 Trull Ave,Greensboro,NC,27455,58094,336-286-5774
494,J Abbott,944 Woodland Dr,Shelby,NC,28150,58115,704-484-6573
495,J H Abbott,307 Trail,Burlington,NC,27215,58136,336-261-2789
496,J L Abbott,469 Drake Ct,Wilmington,NC,28403,58157,910-251-1479
497,J M Abbott,1086 Seashore Dr,Atlantic,NC,28511,58178,252-656-9427
498,J R Abbott,104 Eagle Rd,Belmont,NC,28012,58198,(704) 271-4074
499,J V Abbott,616 S Lakeside Dr,Raleigh,NC,27606,58219,919-740-1480
500,Jack B Abbott,3617 Cove Dr,Raleigh,NC,27604,60320,919-870-9994
501,Jack E Abbott,11 Johnson Dr,Canton,NC,28716,60341,828-648-4568
502,James Abbott,762 Museum Dr,Charlotte,NC,28207,60362,704-596-5728
503,James & Melinda Abbott,900 Gregory St,Greensboro,NC,27403,60382,336-286-5760
504,James C Abbott,1012 Riverside Ave,Elizabeth City,NC,27909,60403,252-335-2246
505,James E Abbott,306 Channing Cir,Concord,NC,28027,60424,704-786-5691
506,James H Abbott,523 Pine Ridge Rd,Banner Elk,NC,28604,60445,828-898-8817
507,James H Abbott,1412 Old Apex Rd,Cary,NC,27513,60466,919-272-9360
508,James Maurice Abbott,109 N 6th St,Spring Lake,NC,28390,60486,910-436-4843
509,Jane Abbott,7114 Claxton Cir,Raleigh,NC,27615,60507,919-740-1488
510,Janet Abbott,1225 S Caldwell St,Charlotte,NC,28203,60528,704-393-5696
511,Janet N Abbott,211 W 4th Ave,Lexington,NC,27292,60549,336-243-1071
512,Janice F Abbott,205 Spruce Hill Ct,Asheville,NC,28805,60570,828-239-8924
513,Janice U Abbott,1111 Pine Level Micro Rd,Selma,NC,27576,60590,919-965-9812
514,Jason Abbott,3508 Garden Rd,Burlington,NC,27215,60611,336-792-5298
515,Jean Abbott,4926 Lindbergh Ave,Kill Devil Hills,NC,27948,60632,252-441-2122
516,Jeff & Michelle Abbott,4836 Beth Ln,Harrisburg,NC,28075,60653,704-455-3050
517,Jeffrey Abbott,309 Edgewater Club Rd,Wilmington,NC,28405,60674,910-251-1481
518,Jennifer Abbott,922 Greenleaf Dr,Fayetteville,NC,28314,60694,910-488-5736
519,Jim & Lauren Abbott,408 Pinecroft Dr,Raleigh,NC,27609,60715,919-870-9999
520,Joey Abbott,1500 Buck Shoals Rd,Hamptonville,NC,27020,60736,336-468-6142
521,John Abbott,2026 La Dora Dr,High Point,NC,27265,60757,336-869-6566
522,John Abbott,5130 Ambercrest Dr,Winston Salem,NC,27106,60778,336-703-1152
523,John R Abbott,12 Jones Rd,Cherry Point,NC,28533,60798,252-636-9678
524,John W Abbott,10 Skyview Pl,Asheville,NC,28804,60819,828-239-2220
525,Johnny Abbott,6109 Buffaloe Rd,Raleigh,NC,27604,60840,919-870-9998
526,Jonathan C Abbott,937 E Sprague St,Winston Salem,NC,27107,60861,336-703-1154
527,Joseph P Abbott,424 Winery Rd,Sneads Ferry,NC,28460,60882,910-327-2405
528,K Abbott,560 Tulane Dr,Wilmington,NC,28403,60902,910-251-1482
529,K O Abbott,2234 Panola St,Tarboro,NC,27886,60923,252-823-9638
530,K S Abbott,906 Epsom Rd,Henderson,NC,27536,60944,252-492-5928
531,Kara Abbott,1202 E 14th St,Greenville,NC,27858,60965,252-752-6984
532,Karen Abbott,4101 N Course Dr,Charlotte,NC,28277,60986,704-596-5701
533,Kathy F Abbott,427 Woods Of North Bend Dr,Raleigh,NC,27609,61006,919-870-9996
534,Katie Abbott,4600 University Dr,Durham,NC,27707,61027,919-598-5694
535,Keith Abbott,303 Grove St,Oxford,NC,27565,61048,919-693-8543
536,Keith & Michelle Abbott,1526 Tramway Ct,Midway Park,NC,28544,61069,910-353-4337
537,Kelly Abbott,5743 Park Ave,Wilmington,NC,28403,61090,910-251-1484
538,Ken & Christine Abbott,10 Stone Point Ln,Apex,NC,27502,61110,919-362-6118
539,Kenneth Abbott,4929 Elmore Dr,Catawba,NC,28609,61131,828-241-7458
540,Kenneth Abbott,1820 Farm St,Henderson,NC,27536,61152,252-492-5930
541,Kenneth B Abbott,7135 Cane Ct,Charlotte,NC,28226,61173,704-596-5699
542,Kenneth B Jr Abbott,516 S Jackson St,Waxhaw,NC,28173,61194,704-843-1892
543,Kenneth L Abbott,665 Eagle Dr,Boone,NC,28607,61214,828-355-4577
544,Kermit L Abbott,517 E 15th St,Lumberton,NC,28358,61235,910-739-6387
545,L Abbott,16 Pebblerbrook Dr,Arden,NC,28704,61256,828-633-8542
546,L Abbott,1 Chestnut St,Granite Falls,NC,28630,61277,828-396-7533
547,L Abbott,137 Gaddy Dr,Wilmington,NC,28403,61298,910-251-1483
548,L Abbott,3411 Gladstone St,Winston Salem,NC,27104,61318,336-703-1153
549,L E Abbott,421 Antoinette Dr,Wilmington,NC,28412,61339,910-251-1480
550,L H Abbott,2111 Thomas Ln,Henderson,NC,27536,61360,252-492-5925
551,L M Abbott,22 Pharr St,Canton,NC,28716,61381,828-648-7468
552,L T Abbott,1025 County Home Rd,Henderson,NC,27536,61402,252-492-5926
553,La-Meeka Abbott,800 Forge Rd,Durham,NC,27713,61422,919-598-5696
554,Larry & Karen Abbott,1001 Charter Hills Rd,Banner Elk,NC,28604,61443,828-898-1567
555,Laura B Abbott,1745 Hendersonville Rd,Asheville,NC,28803,61464,828-239-2742
556,Lawrence E Abbott,108 W Carr,Mebane,NC,27302,61485,919-563-6495
557,Lea E Abbott,218 Spring St,Thomasville,NC,27360,61506,336-476-4998
558,Lee Abbott,9 Acornridge Ct,Durham,NC,27707,61526,919-598-5695
559,Lee Abbott,2406 Burnette Dr,Greensboro,NC,27406,61547,336-286-5751
560,Leona Abbott,8116 Scottview Dr,Charlotte,NC,28214,61568,704-596-5698
561,Leroy Abbott,6258 Burlington Rd,Gibsonville,NC,27249,61589,336-449-6185
562,Linda K Abbott,2816 Kilbourne Dr,Greensboro,NC,27407,61610,336-286-5738
563,Louis Abbott,615 Raynor St,Durham,NC,27703,61630,919-598-5692
564,Louise Abbott,2035 Edgewood Rd,Wilkesboro,NC,28697,61651,336-667-1797
565,Luhter D Abbott,318 Brandywine Rd,Chapel Hill,NC,27516,61672,919-942-1243
566,M Abbott,949 Brookside Camp Rd,Hendersonville,NC,28792,61693,828-685-8692
567,M B Abbott,34 Red Oak Forest Rd,Fairview,NC,28730,61714,828-628-1966
568,M E Abbott,732 Boddie St,Henderson,NC,27536,61734,252-492-5931
569,M G Abbott,137 Smith Corner Rd,Camden,NC,27921,61755,252-335-7584
570,M J Abbott,1602 Elizabeth Dr,Kinston,NC,28501,61776,252-527-0316
571,M L Abbott,706 W D St,Butner,NC,27509,61797,919-575-4893
678,William & Sigrid Abbott,1401 Kelston Pl,Charlotte,NC,28212,66102,704-596-5727
679,William A Abbott,421 Ivey St,Henderson,NC,27536,66123,252-492-5911
680,William E Abbott,342 Ridgecrest Dr,King,NC,27021,66144,336-983-0272
681,William E Abbott,402 Brampton Close W,Pittsboro,NC,27312,66165,919-542-0754
682,William G & Claudia Abbott,814 S Dogwood Ln,Swansboro,NC,28584,66186,252-393-8685
683,William L Abbott,1110 Hickory Tree Rd,Winston Salem,NC,27127,66206,336-703-1143
684,William R Abbott,7099 US Highway 301 S,Four Oaks,NC,27524,66227,919-963-2014
685,William R & Marece Abbott,130 W Pond Creek Rd,Banner Elk,NC,28604,66248,828-963-7591
686,Wm Wallace Abbott,141 Hillside Dr Ggcc,Linville,NC,28604,66269,828-733-8673
687,Wm Wallace Abbott,141 Hillside Dr Ggcc,Linville,NC,28604,66290,828-733-5213
688,James M Abbotts,4318 Pemberton Dr,Charlotte,NC,28210,66310,704-375-5706
689,Karen & William Abbotts,5723 Brisbane Dr,Chapel Hill,NC,27514,66331,919-942-1234
690,William Abbotts,5951 Brace Rd,Charlotte,NC,28211,66352,704-393-5721
691,William C & Sonia Abboud,8834 Hunter Ridge Dr,Charlotte,NC,28226,66373,704-393-5710
692,Kim Abbruscato,2416 Nation Ave,Durham,NC,27707,66394,919-598-5707
693,Bill & Fran Abbruzzese,104 Ann St,Beaufort,NC,28516,66414,252-240-7489
694,David & Camille Abbruzzese,4412 Hunters Run,Clemmons,NC,27012,66435,336-766-5689
695,Emanuel Abbruzzese,622 Elizabethan Ct,Wilmington,NC,28409,66456,910-251-1468
696,Fran Abbruzzese,104 Ann St,Beaufort,NC,28516,66477,252-240-6937
697,Muna Abbud,1310 Corton Dr,Charlotte,NC,28203,66498,704-393-5715
698,Dan Abbuhl,3819 E Hwy,Midland,NC,28107,66518,704-888-5812
699,Geoff Abbuhl,553 Interceptor Rd,Pope A F B,NC,28308,66539,
700,John & Lyn Abbuhl,25 Glendale Oaks Ct,Greensboro,NC,27406,68640,336-286-5761
701,Raghunath Abburi,210 Fairway Dr,Oxford,NC,27565,68661,919-693-9687
702,Margaret Abbushl,1401 E Millbrook Rd,Raleigh,NC,27609,68682,919-870-9983
703,Ilyas Abbyshi,7112 Woodbend Dr,Raleigh,NC,27615,68702,919-870-9992
704,Pediatrics Of Dunn Pa Abc,700 Tilghman Dr,Dunn,NC,28334,68723,910-892-7333
705,Pediatrics Of Dunn Pa Abc,700 Tilghman Dr,Dunn,NC,28334,68744,910-892-7784
706,System Abc,106 Marine Blvd,Jacksonville,NC,28540,68765,910-347-4722
707,Sandra M MD Abda,10000 Park Cedar Dr,Charlotte,NC,28210,68786,704-393-5716
708,Sakinah Abdal-Rafi,2612 Elmhurst Cir,Raleigh,NC,27610,68806,919-870-9986
709,Sakinah Abdal-Rafi,709 Hampstead Pl,Raleigh,NC,27610,68827,919-870-9981
710,A J Abdalla,1114 S 1st St,Smithfield,NC,27577,68848,919-934-8101
711,Abdelrahman Abdalla,6423 The Lakes Dr,Raleigh,NC,27609,68869,919-870-9985
712,Belal Abdalla,9004 E Wt Harris Blvd,Charlotte,NC,28227,68890,704-375-5703
713,George Mrs Abdalla,418 Pecan Dr,Selma,NC,27576,68910,919-965-0951
714,Joseph Abdalla,705 W Anderson St,Selma,NC,27576,68931,919-965-6571
715,Joseph & Sony Abdalla,113 Parkwind Ct,Apex,NC,27502,68952,919-363-5678
716,Majed Abdalla,5515 W Market St,Greensboro,NC,27409,68973,336-286-5772
717,Naser Abdalla,109 Ramblewood Dr,Raleigh,NC,27609,68994,919-870-9995
718,Thomas L Abdalla,709 W Main St,Benson,NC,27504,69014,919-894-1278
719,V D Abdalla,709 W Main St,Benson,NC,27504,69035,919-894-7844
720,V D Abdalla,709 W Main St,Benson,NC,27504,69056,919-894-9671
721,Faatima Abdallah,1219 Moreland Ave,Durham,NC,27707,69077,919-598-5728
722,Fawky Phd Consltnt Abdallah,226 Cedar Trl,Winston Salem,NC,27104,69098,336-703-1141
723,Fawky Phd Res Abdallah,226 Cedar Trl,Winston Salem,NC,27104,69118,336-703-1142
724,Ibrahim S Abdallah,625 Cardinal Gibbons Dr,Raleigh,NC,27606,69139,919-870-9997
725,J Kim Abdallah,305 Coorsdale Dr,Cary,NC,27511,69160,919-740-2211
726,Jarallah Abdallah,702 N Spence Ave,Goldsboro,NC,27534,69181,919-735-5738
727,John H Abdallah,2021 Stephens Ct,Goldsboro,NC,27530,69202,919-735-5739
728,Khaled Abdallah,3801 Knickerbocker Pky,Raleigh,NC,27612,69222,919-740-1475
729,Shereef Abdallah,4236 Lake Ridge Dr,Raleigh,NC,27604,69243,919-740-1476
730,Shereef Abdallah,4236 Lake Ridge Dr,Raleigh,NC,27604,69264,919-740-1478
731,Onar Abde,1110 Elizabeth Rd W,Wilson,NC,27893,69285,252-291-4316
732,Ahmed Abdel,310 N Gulf St,Sanford,NC,27330,69306,919-776-1037
733,Amra K Abdel,405 Pine Knoll Dr,Kinston,NC,28501,69326,252-527-0314
734,Salah Dr Abdel-Aleem,4016 Lake Point Cir,Raleigh,NC,27606,69347,919-740-1481
735,Atef L Abdel-Aveem,3946 Marcom St,Raleigh,NC,27606,69368,919-740-1482
736,Samy Abdel-Baky,921 Tanglewood Dr,Cary,NC,27511,69389,919-531-9528
737,Mohamed M Abdel-Hady,520 Harvard St,Raleigh,NC,27609,69410,919-740-1483
738,Laila Abdel-Malek,4301 Central Ave,Charlotte,NC,28205,69430,704-375-5702
739,Taher Abdel-Messih,2438 Hamilton Mill Rd,Charlotte,NC,28270,69451,704-375-5704
740,Ali Abdel-Qader,5515 W Market St,Greensboro,NC,27409,69472,336-286-5769
741,Sultan Abdel-Qader,203 Tate St,Greensboro,NC,27403,69493,336-286-5735
742,Abdel Abdel-Rahman,389 Claredon Dr,Greenville,NC,27858,69514,252-752-6991
743,Hussein Abdel-Wahab,4814 Fortunes Ridge Dr,Durham,NC,27713,69534,919-598-5698
744,Alaa Abdelazim,5501 Yadkin Rd,Fayetteville,NC,28303,69555,910-488-5743
745,Jodie Abdelaziz,208 N Beaumont Ave,Burlington,NC,27217,69576,336-261-6439
746,Maamoon Abdelaziz,4900 Cricklewood Ln,Charlotte,NC,28212,69597,704-375-5705
747,Nidal Abdelaziz,3248 S Holden Rd,Greensboro,NC,27407,69618,336-286-5740
748,Raed Abdelaziz,6546 Quail Hollow Rd,Charlotte,NC,28210,69638,704-375-5701
749,Hassan A Abdelfatah,202 Golden Dr,Lexington,NC,27292,69659,336-243-1070
750,Helen Abdelfattah,605 Tulane Dr,Wilmington,NC,28403,69680,910-251-1475
751,Iyad F Abdelfattah,6213 N Hills Dr,Raleigh,NC,27609,69701,919-740-1479
752,Mahjoub Abdelgadir,817 Summit Ave,Greensboro,NC,27405,69722,336-286-5750
753,Zaid M Abdelhaq,4011 Rosehaven Dr,Charlotte,NC,28205,69742,704-393-5709
754,A A Abdeljaber,402 Benton St,Goldsboro,NC,27530,69763,919-735-5737
755,Ahmed Abdeljaberm,426 E Elm St,Goldsboro,NC,27530,69784,919-735-5736
756,Elfadil Abdelkabir,108 Lincoln St,Belmont,NC,28012,69805,704-271-4156
757,A M Abdelkader,1039 Sanford Rd,Pittsboro,NC,27312,69826,919-542-6734
758,Trina & Amin Abdelkader,1058 Sanford Rd,Pittsboro,NC,27312,69846,919-542-1597
759,Adnan S Abdelkaleq,329 Key West Mews,Cary,NC,27513,69867,919-272-4175
760,J C Abdell,9 Donnybrook Ct,Asheville,NC,28806,69888,828-225-3694
761,Abdelfattah M Abdelmajid,1527 Lakedell Dr,Charlotte,NC,28215,69909,704-393-5723
762,Dalia Abdelmalek,5616 Farm Pond Ln,Charlotte,NC,28212,69930,704-393-5712
763,Hassan Abdelnabi,5936 Carpenter Dr,Charlotte,NC,28226,69950,704-375-5699
764,Ahmad Dr & Sheila Abdelnaser,5856 Old Oak Ridge Rd,Greensboro,NC,27410,69971,336-286-5741
765,George & Sand Abdelnour,2125 Treverton Pl,Raleigh,NC,27609,69992,919-870-9984
766,Khalid Abdelrahim,2412 Still Forest Pl,Raleigh,NC,27607,70013,919-870-9975
767,Diane Abdelrahman,325 Grandin Rd,Charlotte,NC,28208,70034,704-393-5713
768,Joslynn Abdelrahman,1901 Delaware Dr,Charlotte,NC,28215,70054,704-393-5718
769,Ezz Abdelsattah,711 Hibbard Dr,Chapel Hill,NC,27514,70075,919-942-1244
770,Thomas M & Lori Abdenour,5917 Dunbarton Way,Raleigh,NC,27613,70096,919-870-9987
771,Thomas M & Lori Fax Line Abdenour,5917 Dunbarton Way,Raleigh,NC,27613,70117,919-870-9988
772,Tirmounia Abdessdik,1616 Chasewood Dr,Charlotte,NC,28212,70138,704-393-5720
773,Abdirashid Abdi,3535 Spanish Quarter Cir,Charlotte,NC,28205,70158,704-375-5693
774,Anab Abdi,2500 Eastway Dr,Charlotte,NC,28205,70179,704-393-5708
775,Fowsia Abdi,2500 Eastway Dr,Charlotte,NC,28205,70200,704-393-5724
776,Jawahir Abdi,2500 Eastway Dr,Charlotte,NC,28205,70221,704-393-5725
777,Mohammed J Abdi,3530 Burner Dr,Charlotte,NC,28205,70242,704-393-5726
778,Ebrahim Abdi-Shiraz,5552 Robinhood Rd,Charlotte,NC,28211,70262,704-393-5727
779,Ihsan Abdin,48 Turner Cir,Soul City,NC,27563,70283,
780,Hassan Abdishiraz,2515 Kenmore Ave,Charlotte,NC,28204,70304,704-393-5728
781,Ahmad Abdlqadr,2920 Chapel Hill Rd,Durham,NC,27707,70325,919-598-5697
782,B Abdo,7604 Mine Valley Rd,Raleigh,NC,27615,70346,919-870-9991
783,Eddie & Joann Abdo,10300 Cedar Circle Dr,Charlotte,NC,28210,70366,704-393-5732
784,Kamal M Abdo,8237 Lowell Valley Dr,Bahama,NC,27503,70387,919-477-1453
785,Jeffrey P Abdou,9514 Willowridge Rd,Charlotte,NC,28210,-999999999,704-375-5689
786,Philip & Kathleen Abdow,1015 E Peleliu Dr,Tarawa Terrace,NC,28543,70429,
787,Memoree Abdu,1370 N Cherry St,Winston Salem,NC,27105,70450,336-703-1168
788,Imad Abdul,7021 Wannamaker Ln,Charlotte,NC,28226,70470,704-375-5691
789,Khader Abdul,208 Montrose Dr,Greensboro,NC,27407,70491,336-286-5764
790,Vivian D Abdul-Allah,124 Choctaw St,Asheville,NC,28801,70512,828-225-2785
791,Saed M Abdul-Aziz,1221 Kelston Pl,Charlotte,NC,28212,70533,704-375-5692
792,Bassel Abdul-Hadi,1005 Village Greenway,Cary,NC,27511,70554,919-460-3276
793,Nazeeh Abdul-Hakeem,2309 Nation Ave Apt,Durham,NC,27707,70574,919-598-5730
794,Kyle G Abdul-Haqq,5824 Reddman Rd,Charlotte,NC,28212,70595,704-375-5690
795,Omar Abdul-Haqq,5042 Chesapeake Rd,Fayetteville,NC,28311,70616,910-488-5744
796,Khaleelah Abdul-Kareem,128 Hunt Club Ln,Raleigh,NC,27606,70637,919-740-1496
797,Hakeem Abdul-Karin,200 Nc Highway,Carrboro,NC,27510,70658,919-967-1796
798,Arnett & Deborah Abdul-Majied,508 Lightwood St,Durham,NC,27703,70678,919-598-5737
799,Jamal Abdul-Malik,5411 Turner Smith Rd,Browns Summit,NC,27214,70699,336-375-1549
800,S Abdul-Mallic,10 Knob Ct,Durham,NC,27703,33280,919-598-5726
801,Sultan & Raja Abdul-Muizz,312 N King Charles Rd,Raleigh,NC,27610,33301,919-740-1498
802,Khadijah Abdul-Mutakallim,2920 Chapel Hill Rd,Durham,NC,27707,33322,919-598-5723
803,Zakiap Abdul-Rahim,424 Faison Ave,Charlotte,NC,28205,33342,704-393-5731
804,Archie Abdul-Rahmaan,617 Cecil St,Durham,NC,27707,33363,919-598-5721
805,Usamah Abdul-Rahmaan,3211 Cedarhurst Dr,Charlotte,NC,28269,33384,704-393-5730
806,Hesham Abdul-Rahman,9020 University City Blvd,Charlotte,NC,28213,33405,704-393-5729
807,Treann Ture Abdul-Rahman,1713 Random Dr,Greensboro,NC,27407,33426,336-286-5778
808,B Abdul-Rashid,306 W Camel St,Greensboro,NC,27401,33446,336-286-5775
809,Karen Abdul-Salaam,527 Wofford Rd,Durham,NC,27707,33467,919-598-5690
810,Karima Abdul-Salaam,2921 Cottage Pl,Greensboro,NC,27455,33488,336-286-5768
811,Farid Abdul-Salam,317 N Beech St,Greensboro,NC,27401,33509,336-286-5754
812,Sarah S N Abdulaziz,2010 N Lakeshore Dr,Chapel Hill,NC,27514,33530,919-942-1240
813,Karen Abdulfattah,4306 Cedarwood Ln,Wilmington,NC,28403,33550,910-251-1470
814,Naser & Robin Abdulfattah,2929 Henslowe Dr,Raleigh,NC,27603,33571,919-740-1489
816,H Abdulkareem,750 Mills St,Raleigh,NC,27608,33613,919-740-1506
817,Said Abdulkhalek,5840 Whitebud Dr,Raleigh,NC,27609,33634,919-740-1507
818,Mohammed Abdull,4011 Rosehaven Dr,Charlotte,NC,28205,33654,704-393-5722
819,Ali Abdulla,805 Channel Dr,Winterville,NC,28590,33675,252-756-8070
820,Ebrahim Abdulla,3553 Mayfair St,Durham,NC,27707,33696,919-598-5736
821,Mustasa Abdulla,2920 Chapel Hill Rd,Durham,NC,27707,33717,919-598-5725
822,Adib Abdullah,1903 James St,Durham,NC,27707,33738,919-598-5708
823,Aesha Abdullah,1403 W Monroe St,Salisbury,NC,28144,33758,704-638-0739
824,Ahmad Abdullah,5924 Cabell View Ct,Charlotte,NC,28277,33779,704-393-5719
825,Bashan M Abdullah,404 Nelson St,Durham,NC,27707,33800,919-598-5701
826,Charles F Abdullah,3263 Calumet Dr,Raleigh,NC,27610,33821,919-870-9966
827,D K Abdullah,5924 Cabell View Ct,Charlotte,NC,28277,33842,704-393-5717
828,Delphine Abdullah,521 Green St,Durham,NC,27701,33862,919-598-5702
829,Elizabeth Abdullah,400 Fayetteville Street Mall,Raleigh,NC,27601,33883,919-870-9973
830,Janice Abdullah,708 Van Buren Rd,Raleigh,NC,27604,33904,919-870-9972
831,Larry Abdullah,3 Suburban Ct,Greensboro,NC,27406,33925,336-286-5755
832,Lorraine Abdullah,2549 Hemphill St,Charlotte,NC,28208,33946,704-393-5714
833,Marcia Abdullah,5601 Whippoorwill St,Durham,NC,27704,33966,919-598-5704
834,Monique Abdullah,1803 Travis Dr,Raleigh,NC,27606,33987,919-870-9970
835,Monique Abdullah,1403 W Monroe St,Salisbury,NC,28144,34008,704-638-8579
836,Muhammad Abdullah,6491 Saint Louis St,Fayetteville,NC,28314,34029,910-488-1879
837,Rukiyah Abdullah,424 Greenbriar Rd,Greensboro,NC,27405,34050,336-286-5749
838,Safiya Abdullah,102 N Spruce St,Winston Salem,NC,27101,34070,336-703-1161
839,Shirlene Abdullah,829 Kennedy Ave,New Bern,NC,28560,34091,252-638-9875
840,T Abdullah,744 N Wendover Rd,Charlotte,NC,28211,34112,704-393-5711
841,Talib Abdullah,712 Linwood Ave,Durham,NC,27701,34133,919-598-5719
842,Yusuf I Abdullah,418 Van Norden St,Washington,NC,27889,34154,252-946-4731
843,Muraweh Abdullalrahman,4113 Peachway Dr,Durham,NC,27705,34174,919-598-5709
844,Munir Abdullan,109 Yeargen Pl,Chapel Hill,NC,27516,34195,919-942-1236
845,Afghan Abdullayev,635 Cotanche St,Greenville,NC,27858,34216,252-752-6989
846,M Y Abdullhai,840 Westway St,Elizabeth City,NC,27909,34237,252-335-8473
847,Basil O Abdulmajid,3307 Briarbend Dr,Greensboro,NC,27410,34258,336-286-5743
848,Umar Abdulraheem,5006 Heritage Dr,Durham,NC,27712,34278,919-598-5700
849,Nijad Abdulrahman,3902 Tara Dr,Raleigh,NC,27609,34299,919-870-9963
850,Jamaal Abdulwahid,2017 Prospect Dr,Charlotte,NC,28213,34320,704-375-5707
851,Nura Abdur-Rahim,3004 Ivy Wood Ln,Durham,NC,27703,34341,919-598-5711
852,Shelda Abdur-Razzaq,1000 N Duke St,Durham,NC,27701,34362,919-598-5712
853,A Abdurahim,200 Seven Oaks Rd,Durham,NC,27704,34382,919-598-5713
855,L Abdurrahim,808 Rugby St,Greensboro,NC,27406,34424,336-286-5752
856,Najah R Abdus-Sabur,900 E Washington St,Greensboro,NC,27401,34445,336-286-5736
857,David Abdus-Salaam,1721 Beverly Rd,Rocky Mt,NC,27801,34466,252-446-3595
858,Raji Abdus-Salaam,413 N Mcdaniel St,Enfield,NC,27823,34486,252-445-3541
859,A M Abdy,102 Windward Ct,Cary,NC,27513,34507,919-272-8730
860,Dan M & Sheila G Abe,1000 Wild Pine Dr,Fayetteville,NC,28301,34528,910-488-5754
861,Fujio Abe,4705 Kingswood St,Greensboro,NC,27410,34549,336-286-5753
862,Jason Abe,1205 Memory Ln,Concord,NC,28025,34570,704-786-5692
863,John F Abe,110 Burton St,Graham,NC,27253,34590,336-570-1491
864,K K Abe,903 N Main St,Burlington,NC,27217,34611,336-261-9956
865,Karon Abe,4411 Beechnut Ln,Durham,NC,27707,34632,919-598-5716
866,Louise Abe,2719 Mountcrest Cir,Concord,NC,28027,34653,704-786-5690
867,Rodney Abe,7145 Brigmore Dr,Charlotte,NC,28226,34674,704-375-5694
868,Ataklty Abebe,123 Chamberlain St,Raleigh,NC,27607,34694,919-870-9957
869,Charlie Abed,8607 E Wt Harris Blvd,Charlotte,NC,28227,34715,704-375-5700
870,Charlie & Sus Abed,4613 Oak Park Rd,Raleigh,NC,27612,34736,919-870-9962
871,David Abed,1526 Tryon Rd,Raleigh,NC,27603,34757,919-870-9968
872,Jean-Claude Abed,3723 Colony Crossing Dr,Charlotte,NC,28226,34778,704-375-5698
873,Samir & Susan Abed,14 Logging Trl,Durham,NC,27707,34798,919-598-5717
874,Osama Abedelrahnan,7416 Idlewild Rd,Charlotte,NC,28212,34819,704-375-5697
875,Frank O Abedi,636 Sugaridge Ln,Fayetteville,NC,28311,34840,910-488-5740
876,T Abedon,1118 Scaleybark Rd,Charlotte,NC,28209,34861,704-375-5696
877,A L Abee,7936 Chapman St,Charlotte,NC,28216,34882,704-375-5695
878,Alan & Karen Abee,909 Tarvia Ave NE,Valdese,NC,28690,34902,828-874-2923
970,Mr. John Q. Smith,719 Madison Ave,Cary,NC,27513,95234,919-555-1212;
971,Johnny Smyth,719 Madison Avenue,Cary,North Carolina,27513
972,"smith, jon q.",719 madisun av.,cary,nc,27513
;;;;
proc sort nodupkey;
	by ContactID ;
run;

/* data sasdata.prospects_std; */
/* 	set sasdata.prospects; */
/* 	select (dqidentify(Contact, 'Field Content')) ; */
/* 		when ('INDIVIDUAL') contact=dqstandardize(Contact,'Name') ;  */
/* 		when ('ORGANIZATION') contact=dqcase(Contact,'Proper (Organization)') ; */
/* 		otherwise contact=propcase(contact) ; */
/* 	 end; */
/* 	 Address=dqStandardize(Address,'Address'); */
/* 	 City=dqstandardize(City,'City'); */
/* 	 State=dqstandardize(State,'State/Province (Abbreviation)'); */
/* 	 Phone=dqstandardize(Phone,'Phone'); */
/* ; */
/* run; */