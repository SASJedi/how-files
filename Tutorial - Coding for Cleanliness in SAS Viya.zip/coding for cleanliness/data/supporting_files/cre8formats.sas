data sasData.formats;
	infile datalines dsd dlm='|' truncover;
	retain FMTNAME 'rowid_fmt';
	input Start:16. Label:$256.;
datalines;
1000|Column name
1001|Data type
1002|Count of values
1003|Name of the column containing the profiled column values
1004|Frequency distribution (high)
1005|Frequency distribution (low)
1006|Maximum value
1007|Maximum length
1008|Mean
1009|Median
1010|Minimum value
1011|Minimum length
1012|Mode
1013|Number of blank values
1014|Null count
1016|Outlier high values
1017|Outlier low values
1018|Pattern frequency distribution (high)
1019|Pattern frequency distribution (low)
1020|Unique patterns
1021|Primary Key Candidate
1022|Standard Deviation
1023|Standard Error
1025|Unique count
1028|ID Analysis
1029|Actual bool
1030|Actual date
1031|Actual integer
1032|Actual real
1033|Actual string
1034|Actual designated
1035|Determined type %
1037|Data length
1038|Ordinal
1039|Number of decimal places specified in format, if a format was associated with the column
1040|null percent
1041|unique percent
1042|pattern unique percent
1043|blank percent
1100|Error message
1101|Metadata allows nulls
;

proc format cntlin=sasData.formats;
run;
