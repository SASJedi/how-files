data sasData.rawContacts;
	set sasData.prospects;
	where ContactID in (7 10 11 14 19 20 28 453 706 918);
	if _n_ in (1 5 9) then Contact=lowcase(Contact);
	else if _n_ in (3 6 10) then Contact=upcase(Contact);
	else Contact=propcase(Contact);
	keep Contact;
run;