data sasData.Contacts;
	length Contact $100 Group $8;
	Retain Group 'Demo';
	infile datalines dsd dlm='|' truncover;
	input Contact:$30. Group:$8.;
datalines;
DBA Mike D Abbott|Demo
DBA Mike Abbott, Inc.|Demo
C/O Mike D Abbott 123-456-7890|Demo
SAS Institute, Inc. 100 SAS Campus Drive, Cary NC 27513|Practice
John Smith, PhD, SAS Institute, Inc. 100 SAS Campus Drive, Cary NC 27513|Practice
S. Holmes, 221B Baker St, New London, CT|Practice
;
