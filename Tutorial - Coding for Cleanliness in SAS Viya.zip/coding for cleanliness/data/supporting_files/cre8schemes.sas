data scheme.city;
  infile datalines dsd truncover;
  input DATA:$50. STANDARD:$50.;
datalines4;
Bellevu,Bellevue
Bellevue,Bellevue
Bellvue,Bellevue
CENTERVILLE,Centerville
Centerville,Centerville
Dane,Dunn
Dunn,Dunn
High Point,Highpoint
HighPoint,Highpoint
Leesburg,Leesburg
Louisburg,Leesburg
MARLOW,Marlowe
Marlow,Marlowe
Mint Hill,Mint Hill
Mt Holly,Mint Hill
N. Ridgeville,North Ridgeville
North Ridgeville,North Ridgeville
PHILADELPHIA,Philadelphia
Philadelphia,Philadelphia
SAINT. Louis,St. Louis
ST LOUIS,St. Louis
ST. LOUIS,St. Louis
Saint Louis,St. Louis
Skokie,Skokie
Skookie,Skokie
St Louis,St. Louis
Tarrant,Trinity
Trinity,Trinity
WOODFIELDS,Woodfields
Winston Salem,Winston-Salem
Winston-Salem,Winston-Salem
Woodfields,Woodfields
NY,New York
HOSKINS,Hoskins
ATHENS,Athens
St. Louis (City),St. Louis
;;;;

filename QKBFile "&path/data/my_schemes/my_city.sch.qkb";
proc dqscheme;
	convert SASTOQKB in=scheme.city
					out=QKBFile;
run;
filename QKBFile clear;
