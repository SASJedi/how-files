/*****************************************************************
 Setup & exploration:
 Run this code and review results and log
*****************************************************************/
/* Sample the Data */
proc SQL number;
	title "Customers";
	select Name,Street1,City, State from sasdq.Customers(obs=10);
	title "Cat Lovers Mailing List";
	footnote "Lines 1, 5, and 10 look suspiciously like cat names...";
	select Name,Address,City, State from sasdq.CatLovers (obs=10);
quit;
title;footnote;

title "Customers Who Are Also Cat Lovers";
proc sql number;
select Cat.Name as CatLoverName
      ,Cust.Name as CustName
      ,cat.Address as CatLoverStreet
      ,cust.Street1 as CustStreet
      ,cat.City as CatLoverCity
      ,cust.City as CustCity 
      ,Cat.State as CatLoverState
      ,Cust.State as CustState
      ,Cat.Zip as CatLoverZip
      ,Cust.Zip as CustZip
	from sasdq.Customers as cust
	   inner join 
    	 sasdq.CatLovers as cat
	on upcase(substr(cat.Address,1,10))=upcase(substr(cust.Street1,1,10))
	   and upcase(cat.City)=upcase(cust.City)
       and upcase(cat.State)=upcase(cust.State)
	   and cat.Zip=cust.Zip
;
quit;
title;

/*****************************************************************
 Solve the problem:
 Surely, more than 3 of our suctomers are cat lovers! 
*****************************************************************/

/*****************************************************************
 Step 1: What match definitions are available in the ENUSA locale?
*****************************************************************/
data _null_;
	num=dqLocaleInfoList('match', 'ENUSA');
run;

/*****************************************************************
 Step 2: 
 Because some of the mailing list names are cat names, we will  
 concatenate the address fields, generate match codes using the
 'City - State/Province - Postal Code' definition to find matches,
 and base our join criteria on the match codes.
 Modify the "Customers Who Are Also Cat Lovers" report to join 
 based on those match codes.
*****************************************************************/
title "Customers Who Are Also Cat Lovers";
footnote "Note rows 2 and 6. Catherine Thomas and James Attwood";
footnote2 "subscribed to Cat Lovers magazine in their cat's names.";
proc sql number;
select cust.CustomerID
	  ,Cat.Name as CatLover
      ,Cust.Name 'CustName'
      ,cat.Address as CatStreet
      ,cust.Street1 'CustStreet'
      ,cat.City as CatCity
      ,cust.City 'CustCity' 
      ,Cat.State as CatState
      ,Cust.State 'CustState'
      ,Cat.Zip as CatZip
      ,Cust.Zip 'CustZip'
	from sasdq.Customers as cust
		inner join 
         sasdq.CatLovers as cat1
	on /* Enter your code here */

	order by cat.Name
;
quit;
title;footnote;

/*****************************************************************
 Step 3: 
 Now, modify the SQL to select only Name from the Cat Lovers
 mailing list and write them into a macro variable named ExcludeMe
 separated by the string "," Suppress the SQL report using the 
 PROC SQL NOPRINT option.
 The PROC SQL INTO clause is documented here:
 https://documentation.sas.com/doc/en/pgmsascdc/default/sqlproc/n1tupenuhmu1j0n19d3curl9igt4.htm
*****************************************************************/
proc sql noprint;
select Cat.Name
    /* add your INTO clause here. */
	from sasdq.Customers as cust
		inner join 
         sasdq.CatLovers as cat
	/* Copy your match code from step 2 here */
	on

;
quit;
%put NOTE: Exclude these &sqlobs names: "%superq(ExcludeMe)";

/*****************************************************************
 Step 4: 
 Create the solicitation mailing list by selecting all rows from 
 sasdq.CatLovers with Name values NOT are in the ExcludeMe list.
*****************************************************************/
proc sql;
create table SolicitationMailingList as
select * 
	from sasdq.CatLovers 
	/* Write your WHERE clause here. Don't forget to resolve ExcludeMe inside double quotes!*/
	where
;
quit;

/*****************************************************************
 Step 5: 
 Run the solicitation mailing list report step below. Review the 
 report and answer the question.

 Question: 
 Which row numbers appear to have subscription in the cat's name
 instead of the cat owner's?  

 Answer:
  
*****************************************************************/
title "Solicitation Mailing List";
proc sql number;
select * 
	from SolicitationMailingList
	order by Name
;	
quit;
title;

/*****************************************************************
 Question: 
 Which row numbers appear to have subscription in the cat's name
 instead of the cat owner's?  

 Answer:
  
*****************************************************************/
