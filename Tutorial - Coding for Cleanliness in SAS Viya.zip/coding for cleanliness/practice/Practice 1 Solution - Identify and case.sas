/*****************************************************************
 Setup & exploration:
 Run this code and review results and log
*****************************************************************/
title "Initial Data";
proc FedSQL;
select Text
	  ,dqidentify(text,'Field Content') as Content
	from sasdq.practice1
;
quit;

data _null_;
	put "NOTE: ENUSA Locale CASE Definitions:";
	num=dqLocaleInfoList('CASE','ENUSA');
run;

/*****************************************************************
 Solve the problem:
 Modify the starter code to use the dqcase function to correct 
 the casing of Text
*****************************************************************/
title "Corrected Data";
proc FedSQL;
select Text
	  ,case (dqidentify(text,'Field Content')) 
	     /* Add your code here */
		  when 'INDIVIDUAL' then dqcase(Text, 'Proper (Name)')
		  when 'ORGANIZATION' then dqcase(Text, 'Proper (Organization)')
		  when 'DELIVERY ADDRESS' then dqcase(Text, 'Proper (Address Number)')
		  else propcase(Text)
	   end as CorrectedText
	from sasdq.practice1
;
quit;
title;
