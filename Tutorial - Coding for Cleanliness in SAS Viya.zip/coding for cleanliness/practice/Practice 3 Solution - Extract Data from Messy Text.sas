/*****************************************************************
 Setup & exploration:
 Run this code and review results and log
*****************************************************************/
/* Review the Data */
title "Practice 3 Raw Data";
data _null_;
	infile "&path/data/rawinfo2.txt" ;
	input;
	file print;
	put _infile_;
run;
title;

/* What extraction definitions are available? */
data _null_;
	num=dqLocaleInfoList('extraction', 'ENUSA');
run;

/* What tokens are available in the Contact Info extraction definition? */
data _null_;
	contactTokens=dqExtInfoGet('Contact Info','ENUSA');
	put contactTokens=;
run;

/*****************************************************************
 Solve the problem:
 Modify the starter code to:
   a. Extract the tokens from the text file using dqExtract
   b. Extract the data from the appropraite tokens with dqExtTokenGet
   c. Standardize that data using dqstandardize
 
Save your results as sasdq.NewCustomers
*****************************************************************/

data sasdq.NewCustomers;
	infile "&path/data/rawinfo2.txt";
	input;
	/* Extract the tokens from the raw data only once for efficiency */
	_tokens=dqextract(_infile_,'Contact Info','ENUSA');
	drop _:;
    /* Get each data value and standardize the text */
	Name=dqstandardize(dqExtTokenGet(_tokens
								,'Name', 'Contact Info', 'ENUSA'),'Name');
	Organization=dqcase(dqExtTokenGet(_tokens
								,'Organization', 'Contact Info', 'ENUSA'),'Proper (Organization)');
	Address=dqStandardize(dqExtTokenGet(_tokens
								,'Address', 'Contact Info', 'ENUSA'),'City - State/Province - Postal Code');
	Email=lowcase(dqExtTokenGet(_tokens
								,'E-mail', 'Contact Info', 'ENUSA'));
	Phone=dqstandardize(dqExtTokenGet(_tokens
								,'Phone', 'Contact Info', 'ENUSA'),'Phone');
run;

title "Practice 3 - New Customer Data";
proc print; 
run;
title;
