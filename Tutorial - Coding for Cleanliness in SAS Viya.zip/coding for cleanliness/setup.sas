/* Get helper macro code from GitHub repository, if required */
%if not %SYSMACEXIST(compress) %then %do;
	filename macro url "https://raw.githubusercontent.com/SASJedi/sas-macros/master/compress.sas";
	%include macro/source2;
%end;
%if not %SYSMACEXIST(translate) %then %do;
	filename macro url "https://raw.githubusercontent.com/SASJedi/sas-macros/master/translate.sas";
	%include macro/source2;
%end;
%if not %SYSMACEXIST(whereami) %then %do;
	filename macro url "https://raw.githubusercontent.com/SASJedi/sas-macros/master/whereami.sas";
	%include macro/source2;
%end;

/* Identify path to current program */
%let path=%whereami();
%put NOTE: Path to course files: %superq(path);

/* Allocate SAS Libraries */
options dlcreatedir;
libname sasData "&path/data";
libname sasData "&path/data/demo";
libname scheme "&path/data/my_schemes";
libname sasDQ "&path/data/practice";
options nodlcreatedir;

/* Start with empty libraries */
proc datasets library=sasdata kill nolist nodetails; run;
proc datasets library=scheme kill nolist nodetails; run;
quit;

/* Create course data files */
%include "&path/data/supporting_files/cre8*.sas" /source2;

/* Create libnames.sas file to simplify future startups & resets */
data _null_;
	file "&path/libnames.sas";
	put 
	'/* Set root path to course files */' /
	'%let path='"&path;" /
	'/* Allocate SAS Libraries */' /
	'libname sasData "&path/data/demo";' /
	'libname sasDQ "&path/data/practice";' //
	'libname scheme "&path/data/my_schemes";' //
	'/* Connect to CAS and caslibs */' /
	'cas conn sessopts=(caslib="casuser" timeout=24800 locale="en_US");' /
	'libname casuser cas SESSREF=conn caslib=casuser;' //
	'/* Copy data from SAS Library to CAS */' /
	'proc copy in=sasdata out=casuser;'/
	'	%if %sysfunc(exist(sasdata.prospects_std)) %then %do; exclude PROSPECTS_STD; %end;'/
	'run; quit;'//
	'/* Ensure the desired qkB is loaded or base SAS and CAS*/' /
	'%dqload(DQSETUPLOC="QKB CI 33", DQLOCALE=(ENUSA), DQINFO=1;)'//
	'proc cas;'/
	'	qkb.loadQKB /qkb="QKB CI 33";'/
	'quit;'//
	'title "Tables in SASDATA and CASUSER libraries";'/
	'proc sql;'/
	'select * from ((select memname as st "SAS Table" from dictionary.tables where libname="SASDATA") as sas'/
	'					full join'/
	'			   (select memname as ct "CAS Table" from dictionary.tables where libname="CASUSER") as cas'/
	'					on st=ct);'/
	';quit;'/
;
run;

cas conn terminate;
%include "&path/libnames.sas";

	