/***************************************************************** 
 Step 1:
 Run this code, the look at the log. 
 What locales are loaded for this session? 
*****************************************************************/
data _null_;
	loadedLocales=dqLocaleInfoGet('loaded');
	put "NOTE:" loadedLocales;
run;

/***************************************************************** 
 Step 2:
 Run this code to use the DQLOAD macro to load and additional 
 locale, then re-run the code in Step 1. 
 What locales are loaded for this session now? 
*****************************************************************/
%DQLOAD(DQSETUPLOC="QKB CI 33", DQLOCALE=(ENUSA PTBRA), DQINFO=1);

/***************************************************************** 
 Step 3:
 Run this code, the look at the log. 
 What locales are loaded for this session? 
*****************************************************************/
data _null_;
	put "NOTE: ENUSA Locale info:";
	num=dqLocaleInfoList('CASE','ENUSA');
    put "NOTE-  "//
		"NOTE: PTBRA Locale info:";
	num=dqLocaleInfoList('CASE','PTBRA');
run;
