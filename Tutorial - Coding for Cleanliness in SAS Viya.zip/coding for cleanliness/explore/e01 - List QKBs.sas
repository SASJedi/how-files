/***************************************************************** 
 Step 1:
 Run this code, the look at the log. 
 Is QKB CI 33 available for this session? 
*****************************************************************/
PROC QKB; 
	LIST;
run;

/***************************************************************** 
 Step 2:
 Run this code, the look at the log. 
 What is the default locale for this session? 
*****************************************************************/
proc options group=dataquality;
run;

